# Mapa de Processos DP e Folha — Cluster Sonova (4 CNPJs)

Mapeamento completo dos processos de RH/DP, coordenador - Anderson Souza.

Paleta Sonova aplicada via `classDef` nos diagramas.

Legenda de cores:
- Azul Sonova `#0083CA` — ponto de entrada / processo principal
- Azul claro `#6EB4DC` — agrupador / subdomínio
- Azul escuro `#003C64` — decisão / checkpoint
- Vinho `#7D0041` — atenção / prazo crítico / encargos
- Verde-petróleo `#005A64` — conclusão / arquivamento
- Branco com borda azul — marco de data

---

## 1. Visão geral

```mermaid
flowchart LR
    HUB(["Gestão de Folha e RH<br/>Cluster Sonova — 4 CNPJs"]):::start

    HUB --> ADM["Admissão"]:::sub
    HUB --> TRF["Transferências entre CNPJs"]:::sub
    HUB --> DES["Desligamento"]:::sub
    HUB --> FOL["Fechamento da Folha"]:::sub
    HUB --> BEN["Benefícios e Lançamentos"]:::sub
    HUB --> PNT["Ponto e Jornada"]:::sub
    HUB --> SST["SST / Segurança"]:::sub
    HUB --> INT["Incorporação de Empresas"]:::sub
    HUB --> CAD["Rotinas por Cadência"]:::sub
    HUB --> COM["Comunicados"]:::sub
    HUB --> GST["Onboarding de Gestores<br/>(nova implantação)"]:::sub

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
```

---

## 2. Admissão

```mermaid
flowchart TD
    T["Talent confirma a Carta Oferta aceita"]:::start
    T --> BV["Eduarda envia boas-vindas"]
    BV --> CK["Checklist digital compartilhado<br/>Talent + DP (dispara no aceite)"]:::deci
    CK --> DOC["Coleta de documentação<br/>(link para o colaborador subir docs)"]
    DOC --> EX["Exame médico admissional"]
    DOC --> VT["Vale Transporte"]
    DOC --> VR["Vale Refeição"]
    EX --> REV["Eduarda revisa e aprova"]
    VT --> REV
    VR --> REV
    REV --> DP["Inclusão na DP / sistema"]

    DP --> QZ["Registro de opção pelo quinzenal<br/>(documentado no cadastro)"]
    DP --> CTPS["CTPS digital + consignados<br/>(na admissão inicial)"]
    DP --> SUL["Atualizar SulAmérica e VT"]
    DP --> INTEG["Treinamento de integração obrigatório<br/>com certificação (Anvisa / RDC 665)"]:::aten
    INTEG --> CONF["Conferência mensal dos<br/>certificados de integração"]
    DP --> PNT["Incluir no sistema de ponto<br/>(laboratório) + confirmar no 1º dia útil"]
    DP --> COMA["Comunicado de admissão<br/>(jornada, ponto, benefícios)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 3. Transferências entre CNPJs

```mermaid
flowchart TD
    SOL["Solicitação formal de transferência<br/>(formulário digital padrão)"]:::start
    SOL --> GR["Gerente regional registra a mudança"]
    GR --> VIS["RH com visibilidade<br/>antes do processamento da folha"]:::deci
    VIS --> CONF["Amarrar na etapa de conferência da folha"]
    CONF --> OK["Cada CNPJ com as pessoas corretas<br/>(ciclo fechado, sem quebra de comunicação)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 4. Desligamento

```mermaid
flowchart TD
    GAT["Gatilho de desligamento"]:::start
    GAT --> CKD["Checklist de Desligamento<br/>(antes da rescisão)"]:::deci
    CKD --> M1["Devolução de materiais"]
    CKD --> M2["Consentimento de exclusão de arquivos"]
    CKD --> M3["Termo correto<br/>(aviso prévio, justa causa, etc.)"]
    M1 --> RES["DP processa a rescisão"]
    M2 --> RES
    M3 --> RES

    GAT --> CD["Comissões de desligados<br/>prazo D+2 após o desligamento"]:::aten
    CD --> FCP["Input prioritário na folha complementar"]
    GAT --> IFO["Ajustar iFood na demissão"]

    RES --> COMD["Comunicado de desligamento<br/>(prazos e direitos)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 5. Fechamento da Folha (ciclo completo)

```mermaid
flowchart TD
    A["1. Calcular folha com<br/>todas as rubricas já lançadas"]:::start
    A --> B["2. Conferência com sistema de outliers"]:::deci
    B --> C["3. Incluir comissões fora do fluxo<br/>(Lilian / regionais)"]
    C --> D["4. Consolidar e verificar o líquido final"]
    D --> E["5. Separar folhas por áreas"]
    E --> F["6. Calcular FTEs (full-time equivalents) para as HRMs"]
    F --> G["7. Gerar arquivos bancários"]
    G --> H["8. Subir no BankManager"]
    H --> I["9. Aprovações no Pipefy e no SSA"]
    I --> J["Pré-conferência de encargos<br/>INSS / FGTS / eSocial (antes da semana 1)"]:::aten
    J --> K["10. Conferência final de encargos<br/>INSS / FGTS antes de enviar ao banco"]:::aten
    K --> L["11. Fechar e arquivar<br/>comprovantes + folha final (auditoria)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 6. Calendário de lançamentos (inputs da folha)

```mermaid
flowchart LR
    D1(["Dia 1"]):::date
    D1 --> U1["Upload de bases:<br/>Sonova Cuida, Unives, Wellhub, Petlove"]
    D1 --> U2["Consignado + Copay"]
    D1 --> U3["Seguro de vida<br/>(incluir admitidos / retirar desligados)"]

    D2(["Dia 2"]):::date --> G["Gympass"]
    DX(["<p></p><p>Dia 20</p><p></p>"]):::date --> CR["Creche e Educação"]
    IFC(["Ao comprar"]):::date --> IF["iFood gera automaticamente"]
    D20(["Dia 20"]):::date --> CM["Recebimento de comissões"]
    D21(["Dia 21"]):::date --> VC["Validação de comissões"]

    classDef date fill:#fff,stroke:#0083CA,stroke-width:2px,color:#0083CA;
```

---

## 7. Férias (duas janelas fixas)

```mermaid
flowchart TD
    J1(["Janela 1 — até o dia 20"]):::date
    J1 --> F1["Calcular férias que iniciam<br/>no começo do próximo mês"]
    F1 --> FF["Entram no 1º cálculo, junto com a folha<br/>(garante pagamento no mês corrente)"]:::done

    J2(["Janela 2 — 1ª semana do mês seguinte"]):::date
    J2 --> F2["Calcular férias que iniciam mais adiante"]

    classDef date fill:#fff,stroke:#0083CA,stroke-width:2px,color:#0083CA;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 8. Benefícios — VT / VR / VA

```mermaid
flowchart TD
    FC["Folha fechada<br/>(antes do dia 15)"]:::start
    FC --> CS["Conferência de saldo"]:::deci
    CS --> XR["Cruzar bases VT x VR<br/>checar saldo de todos os CNPJs"]
    XR --> CP["Compra consolidada (única)"]
    CP --> RB["VT via RB Ticket"]
    CP --> IFV["VR / VA via iFood"]
    RB --> OK["Benefícios comprados no prazo, sem erro"]:::done
    IFV --> OK

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 9. Quinzenal

```mermaid
flowchart TD
    AD["Admissão"]:::start --> OP["Registro de opção pelo quinzenal<br/>(no cadastro)"]
    OP --> FT["Filtro: somente quem optou"]:::deci
    FT --> P15["Dia 15 — pagamento apenas aos optantes"]:::done

    NQ["Empresas sem quinzenal"]:::start --> FN["Seguem o fluxo normal"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 10. Ponto e jornada

```mermaid
flowchart LR
    P["Gestão de Ponto e Jornada"]:::start

    P --> BA["Quem bate ponto"]:::sub
    BA --> R1["Relógio funcionando + horários configurados"]
    BA --> R2["Ciclo de fechamento antes do fim do mês"]
    R2 --> R3["Conferir horas extras e faltas"]

    P --> NB["Quem não bate ponto"]:::sub
    NB --> N1["Controle de jornada alternativo"]
    NB --> N2["Acordo individual de horário flexível"]
    N2 --> N3["Revisões periódicas da jornada"]

    P --> LAB["Laboratório (na admissão)"]:::sub
    LAB --> L1["Incluir no sistema de ponto na entrada"]
    L1 --> L2["Confirmar habilitação no 1º dia útil"]
    L2 --> L3["Orientar o colaborador a registrar as marcações"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
```

---

## 11. SST / Segurança

```mermaid
flowchart LR
    SST["SST / Segurança"]:::start

    SST --> V["Vencimentos e laudos"]:::sub
    V --> V1["Validade de PGR<br/>(relatório com a Essência + alertas)"]
    V --> V2["EPI / PGR"]
    V --> V3["Atualização de laudos (LTCAT)"]

    SST --> TR["Treinamentos"]:::sub
    TR --> T1["NR-5 (CIPA)"]
    TR --> T2["NR-6 (EPI)"]
    TR --> T3["Reciclagem periódica"]

    SST --> EM["Emergência e rotina"]:::sub
    EM --> E1["Revisão anual do plano de emergência"]
    EM --> E2["DDS — Diálogo Diário de Segurança"]
    EM --> E3["Auditorias internas de rotina"]
    EM --> E4["Comunicação formal de incidentes"]:::aten
    EM --> E5["Revisão dos procedimentos de emergência"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 12. Incorporação de empresas (meta: até 60 dias)

```mermaid
flowchart LR
    I["Incorporação de Empresa<br/>(meta: até 60 dias)"]:::start

    I --> C1["Revisar contratos de trabalho → aditivos"]
    C1 --> C2["Transferência de responsabilidades no contrato"]

    I --> M1["Migração de dados de folha e benefícios"]
    M1 --> M2["Portabilidade de plano de saúde / odonto"]
    M2 --> M3["Adequação de benefícios (VR, VA, previdência)"]
    M3 --> M4["Migração de férias e banco de horas"]

    I --> S1["EPIs e treinamentos de segurança alinhados"]
    I --> S2["Atualizar cadastro (novos gestores e cargos)"]
    S2 --> S3["Integração no eSocial"]

    I --> P1["Formalização de políticas internas"]
    P1 --> P2["Atualizar acessos a sistemas internos"]
    P2 --> P3["Revisitar política de LGPD"]:::aten

    I --> CC["Comunicação clara aos colaboradores<br/>sobre o novo vínculo"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 13. Rotinas por cadência

```mermaid
flowchart LR
    CAD["Rotinas por Cadência"]:::start

    CAD --> DI["Diárias"]:::sub
    DI --> DI1["RH Informs (chamados) — janela fixa,<br/>macro no Google Sheets organiza as respostas"]
    DI --> DI2["Atestados — registrar no eSocial<br/>em até 1 dia útil"]:::aten
    DI --> DI3["Centralizar atestados via RH Informs / formulário"]
    DI --> DI4["Controle de acesso à DP"]

    CAD --> SE["Semanais"]:::sub
    SE --> SE1["Controle Solan (sexta-feira) —<br/>revisar notas e aprovar lançamentos"]

    CAD --> ME["Mensais"]:::sub
    ME --> ME1["FAP — consultar alíquota e ajustar por CNPJ<br/>antes do fechamento"]
    ME --> ME2["Validade de PGRs"]
    ME --> ME3["Atualização das bases de benefícios"]

    CAD --> SM["Semestrais"]:::sub
    SM --> SM1["Igualdade salarial"]

    CAD --> AN["Anuais"]:::sub
    AN --> AN1["Budget (último trimestre)"]
    AN --> AN2["DIRF / RAIS (início do ano)"]
    AN --> AN3["BSC (início do ano)"]
    AN --> AN4["Vacinação (2º semestre)"]
    AN --> AN5["Cartas de promoção e mérito (abril e outubro)"]
    AN --> AN6["PLR — comissão no início, checkpoints<br/>trimestrais, pagamento no fim do ano"]
    AN --> AN7["Revisão de CCT / convenções coletivas"]
    AN --> AN8["Auditoria interna de DP / RH"]
    AN --> AN9["Revisão de política de benefícios e clima"]
    AN --> AN10["Impacto do salário mínimo e faixas de IR"]
    AN --> AN11["Cotas de aprendizes e PCD"]
    AN --> AN12["Reavaliação de cargos e salários + plano de sucessão"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 14. Comunicados-chave

```mermaid
flowchart LR
    C["Comunicados-chave"]:::start
    C --> C1["Admissão<br/>(jornada, ponto, benefícios)"]
    C --> C2["Desligamento<br/>(prazos e direitos)"]
    C --> C3["Atualização anual<br/>(PLR, reajustes, CCT)"]
    C --> C4["Geral<br/>(prazos de atestados, férias, ponto)"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
```

---

## 15. Onboarding de gestores (nova implantação / mudança de regra)

```mermaid
flowchart TD
    NI["Nova implantação ou mudança de regra"]:::start
    NI --> MF["Microfluxo de adaptação (antes)"]:::deci
    MF --> MO["Mini onboarding dos gestores<br/>(nova cultura, regras, pontos de atenção)"]
    MO --> FN["Inserir no fluxo padrão"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```


---

## 16. Governança geral de demandas DP/RH

### Objetivo
Organizar a entrada, classificação, priorização, execução, evidência e encerramento das demandas de Departamento Pessoal, Folha, Benefícios, Ponto, SST e rotinas administrativas de RH.

### Regras do processo
- Toda demanda deve entrar por canal formal: RH Informs, e-mail corporativo, Pipefy, formulário, planilha de controle ou solicitação formal do gestor.
- Demandas verbais devem ser registradas antes da execução quando houver impacto em folha, pagamento, benefício, contrato, desligamento, ponto, SST ou obrigação legal.
- Toda demanda deve possuir responsável principal, prazo, status e evidência de conclusão.
- Demandas com impacto financeiro ou legal devem ter aprovação formal antes do lançamento.
- Demandas sem evidência não devem ser consideradas concluídas.

### Classificação sugerida
| Tipo de demanda | Exemplos | Criticidade padrão |
|---|---|---|
| Folha/Pagamento | salário, comissão, rescisão, férias, quinzenal, diferença salarial | Alta |
| Legal/Obrigação | eSocial, FGTS, INSS, IRRF, DCTFWeb, CCT, prazo rescisório | Alta |
| Benefícios | VT, VR/VA, saúde, odonto, seguro, Wellhub, Petlove, Univers | Média/Alta |
| Ponto/Jornada | faltas, atrasos, HE, banco de horas, escala, intervalo | Média/Alta |
| SST | ASO, PGR, PCMSO, LTCAT, EPI, CAT, CIPA | Alta |
| Cadastro | alteração salarial, cargo, centro de custo, gestor, dependentes | Média/Alta |
| Fornecedores | notas, faturas, boletos, contestação, pagamento | Média |
| Comunicação | comunicados, orientações, onboarding de gestores | Média |

### SLA operacional sugerido
| Criticidade | Prazo de resposta | Prazo de tratamento | Exemplo |
|---|---:|---:|---|
| Alta | Mesmo dia | Até 1 dia útil | pagamento, rescisão, eSocial, benefício crítico, ASO admissional |
| Média | Até 1 dia útil | Até 3 dias úteis | alteração cadastral, ponto, fatura, benefício comum |
| Baixa | Até 2 dias úteis | Até 5 dias úteis | dúvidas, comunicados, ajustes sem impacto financeiro |

### Evidências mínimas
| Processo | Evidência obrigatória |
|---|---|
| Folha | base de input, relatório de conferência, folha final, comprovante bancário |
| Benefícios | base enviada, protocolo do fornecedor, fatura, memória de conferência |
| Rescisão | checklist, cálculo, TRCT, eSocial, FGTS, comprovante, ASO quando aplicável |
| Admissão | checklist, documentos, ASO, cadastro, comunicado, integração |
| Ponto | espelho, justificativa, aprovação do gestor, relatório de exceções |
| SST | ASO, laudo, ficha de EPI, certificado, protocolo, relatório fornecedor |
| Fornecedores | nota fiscal, contrato/pedido, aprovação, comprovante de pagamento |

---

## 17. Movimentações cadastrais e contratuais

### Objetivo
Controlar alterações que impactam cadastro, folha, encargos, benefícios, ponto, centro de custo, cargo, gestor, jornada e obrigações trabalhistas.

### Fluxo operacional
```mermaid
flowchart TD
    SOL["Solicitação formal de movimentação"]:::start
    SOL --> VAL["Validar aprovação, vigência e impacto"]:::deci
    VAL --> TIPO["Classificar tipo de movimentação"]
    TIPO --> SAL["Alteração salarial / mérito / promoção"]
    TIPO --> CARGO["Cargo, função, CBO ou centro de custo"]
    TIPO --> JORN["Jornada, escala, local ou gestor"]
    TIPO --> DEP["Dependentes, dados bancários ou dados pessoais"]
    SAL --> DOC["Gerar carta, aditivo ou evidência"]
    CARGO --> DOC
    JORN --> DOC
    DEP --> DOC
    DOC --> SIS["Atualizar sistemas e folha"]
    SIS --> CONF["Conferir reflexo em folha, ponto e benefícios"]:::deci
    CONF --> ARQ["Arquivar evidência e comunicar envolvidos"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Checklist detalhado
| Movimentação | Conferências necessárias | Evidência |
|---|---|---|
| Alteração salarial | aprovação, vigência, salário anterior, novo salário, motivo, rubrica, impacto em encargos | carta, e-mail de aprovação, print/cadastro |
| Promoção | cargo, salário, CBO, gestor, centro de custo, elegibilidade a bônus/comissão | carta de promoção, aprovação, cadastro atualizado |
| Mérito | percentual, orçamento, data-base, elegibilidade, comunicação | carta de mérito, base aprovada |
| Cargo/função | CBO, descrição, sindicato, risco ocupacional, necessidade de ASO | aditivo/carta, cadastro, ASO se aplicável |
| Jornada | escala, intervalo, ponto, salário-hora, banco de horas, acordo individual | aditivo, escala, sistema de ponto |
| Centro de custo | origem, destino, vigência, impacto contábil e rateio | solicitação aprovada, cadastro atualizado |
| Gestor | aprovador de ponto, férias, chamados, metas e comunicação | cadastro/sistema atualizado |
| Local/unidade | sindicato, VT, risco, jornada, gestor, benefícios | aditivo/comunicação, cadastro atualizado |
| Dados bancários | titularidade, CPF, banco, agência, conta, prazo de corte | formulário/evidência do colaborador |
| Dependentes | IRRF, salário-família, saúde, odonto, documentação | documentos e cadastro atualizado |

---

## 18. Folha complementar e pagamentos fora do ciclo

### Objetivo
Tratar diferenças ou pagamentos que não entraram no fechamento mensal normal, evitando pagamentos sem autorização, sem incidência correta ou sem evidência.

### Gatilhos possíveis
- Comissão enviada fora do prazo.
- Comissão de desligado recebida após a rescisão.
- Diferença salarial retroativa.
- Reajuste de CCT ou dissídio.
- Correção de rubrica lançada incorretamente.
- Férias, rescisão ou 13º com diferença apurada posteriormente.
- Pagamento de prêmio, bônus, garantia de comissão ou variável excepcional.
- Decisão jurídica ou acordo individual/coletivo.

### Fluxo operacional
```mermaid
flowchart TD
    GAT["Identificação de diferença ou pagamento fora do ciclo"]:::start
    GAT --> DOC["Receber base, autorização e justificativa"]
    DOC --> INC["Validar rubrica, incidências e competência"]:::deci
    INC --> CALC["Calcular folha complementar ou programar na próxima folha"]
    CALC --> ENC["Conferir INSS, FGTS, IRRF, eSocial e DCTFWeb"]:::aten
    ENC --> PAG["Gerar pagamento / arquivo bancário"]
    PAG --> ARQ["Arquivar cálculo, autorização e comprovante"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Controles obrigatórios
| Controle | Descrição |
|---|---|
| Motivo do pagamento | diferença, comissão, reajuste, erro, decisão, prêmio ou retroativo |
| Competência correta | mês de origem da verba e mês de pagamento |
| Incidências | INSS, FGTS, IRRF, eSocial, DCTFWeb e reflexos |
| Aprovação | gestor, controladoria, RH, jurídico ou coordenação conforme o caso |
| Forma de pagamento | folha complementar, próxima folha, rescisão complementar ou pagamento avulso autorizado |
| Evidência | memória de cálculo, base aprovada, comprovante e arquivo final |

---

## 19. Encargos, eSocial e obrigações acessórias

### Objetivo
Garantir que os encargos e obrigações trabalhistas/previdenciárias sejam fechados corretamente por CNPJ, dentro do prazo e com evidências suficientes para auditoria.

### Fluxo operacional
```mermaid
flowchart TD
    FOL["Folha calculada e conferida"]:::start
    FOL --> ESOC["Fechamento eSocial / totalizadores"]:::deci
    ESOC --> INSS["Conferir INSS / DCTFWeb"]:::aten
    ESOC --> FGTS["Conferir FGTS Digital"]:::aten
    ESOC --> IRRF["Conferir IRRF / bases tributáveis"]:::aten
    INSS --> GUIA["Emitir guias e relatórios"]
    FGTS --> GUIA
    IRRF --> GUIA
    GUIA --> PAG["Enviar para pagamento / aprovação"]
    PAG --> COMP["Baixar comprovantes"]
    COMP --> ARQ["Arquivar guias, recibos e memórias"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Obrigações e controles
| Obrigação | Controle mínimo | Evidência |
|---|---|---|
| eSocial S-1200/S-1210 | fechamento da folha, retornos, totalizadores, divergências | recibos, retornos, relatórios |
| eSocial S-2200/S-2205/S-2206 | admissão, alteração cadastral e contratual | recibos e cadastros |
| eSocial S-2299/S-2399 | desligamentos CLT e não empregados quando aplicável | recibos, TRCT, demonstrativos |
| INSS/DCTFWeb | bases, débitos, compensações, DARF e vencimento | DCTFWeb, DARF, comprovante |
| FGTS Digital | trabalhadores, bases, mensal, rescisório, multa e comprovante | guia, relatório e comprovante |
| IRRF | bases tributáveis, dependentes, férias, PLR, 13º, rescisão | relatório e guia |
| FAP/RAT | conferência por CNPJ antes do fechamento | consulta, print, memória |
| Regularidade | acompanhamento de pendências e possíveis débitos | certidão/relatório quando aplicável |

---

## 20. Benefícios completos

### Objetivo
Controlar inclusão, exclusão, alteração, compra, fatura, desconto em folha, contestação e arquivo de todos os benefícios.

### Fluxo operacional
```mermaid
flowchart TD
    MOV["Movimentação de benefício"]:::start
    MOV --> TIPO["Admissão, desligamento, alteração, dependente, afastamento ou compra mensal"]
    TIPO --> BASE["Atualizar base do fornecedor"]
    BASE --> CONF["Conferir vidas, valores, CNPJ e competência"]:::deci
    CONF --> FAT["Validar fatura / compra / desconto em folha"]
    FAT --> CONT["Contestar divergências quando houver"]:::aten
    FAT --> ARQ["Arquivar base, fatura, aprovação e comprovante"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Benefícios e subprocessos
| Benefício | Subprocessos |
|---|---|
| VT | inclusão, exclusão, endereço, saldo, compra, desconto legal, exceções e arquivo |
| VR/VA iFood | inclusão, exclusão, afastados, desligados, férias, compra, saldo, contestação e arquivo |
| Saúde SulAmérica | inclusão, exclusão, dependentes, fatura, coparticipação, reembolso, portabilidade e contestação |
| Odonto | inclusão, exclusão, dependentes, fatura, coparticipação e conferência |
| Seguro de vida | admitidos, desligados, capital segurado, elegibilidade, fatura e arquivo |
| Wellhub/Gympass | elegibilidade, inclusão, exclusão, fatura, desconto e conferência |
| Petlove | inclusão, exclusão, fatura, elegibilidade, desconto e arquivo |
| Univers Drogaria | movimentação, fatura, desconto em folha, contestação e arquivo |
| Sonova Cuida | base mensal, elegibilidade, desconto/subsídio, conferência e arquivo |
| Previdência | inclusão, alteração de percentual, exclusão, desconto, repasse e arquivo |
| Consignado | base, margem, desconto, retorno, repasse e quitação |
| Copay | recebimento de base, conferência, lançamento em folha, contestação e arquivo |

---

## 21. Afastamentos, atestados e licenças

### Objetivo
Controlar ausências legais e médicas com impacto em ponto, folha, benefício, estabilidade, eSocial e SST.

### Fluxo operacional
```mermaid
flowchart TD
    REC["Receber atestado/licença pelo canal oficial"]:::start
    REC --> VAL["Validar documento, período e tipo de ausência"]:::deci
    VAL --> PNT["Registrar no ponto"]
    VAL --> FOL["Avaliar impacto em folha e benefícios"]
    VAL --> SST["Avaliar necessidade de ASO, CAT ou evento SST"]:::aten
    PNT --> ESOC["Registrar no eSocial quando aplicável"]
    FOL --> ESOC
    SST --> ESOC
    ESOC --> RET["Controlar retorno e estabilidade quando houver"]
    RET --> ARQ["Arquivar evidência com acesso restrito"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Tipos de ocorrência
| Tipo | Controle necessário |
|---|---|
| Atestado até 15 dias | registro no ponto/folha, conferência de dias e retorno |
| Afastamento INSS | controle do 15º dia, benefício, retorno, estabilidade e eSocial |
| Retorno ao trabalho | ASO de retorno quando aplicável, ponto e cadastro |
| Licença maternidade | início, fim, estabilidade, salário-maternidade, eSocial e benefícios |
| Licença paternidade | documentação, prazo e lançamento |
| Acidente de trabalho | CAT, investigação, estabilidade, ASO e eventos SST |
| Afastamento sem remuneração | autorização, aditivo, benefício, folha e encargos |
| Faltas justificadas | casamento, falecimento, doação de sangue, alistamento, vestibular e demais hipóteses legais |

---

## 22. Comissões, bônus, PLR e variáveis

### Objetivo
Controlar remuneração variável com aprovação, regra, elegibilidade, cálculo, incidência, pagamento e evidência.

### Fluxo operacional
```mermaid
flowchart TD
    REC["Receber base de variável"]:::start
    REC --> REG["Identificar regra: comissão, bônus, PLR, prêmio ou garantia"]
    REG --> VAL["Validar elegibilidade, competência, CNPJ, matrícula e aprovação"]:::deci
    VAL --> CALC["Calcular ou importar valores na folha"]
    CALC --> CONF["Conferir incidências e líquido"]:::aten
    CONF --> PAG["Pagar no ciclo correto ou folha complementar"]
    PAG --> ARQ["Arquivar base, aprovação e memória"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Controles por tipo
| Tipo | Controle |
|---|---|
| Comissão mensal | base, regra, elegibilidade, competência, aprovação, rubrica e incidência |
| Comissão fora do fluxo | Lilian, Clarice, regionais, wholesale, garantias, prêmios e exceções |
| Comissão de desligados | solicitação D+2, validação, folha complementar/rescisão complementar e arquivo |
| Comissão trimestral | apuração, validação gerencial, consolidação e pagamento |
| Garantia de comissão | elegíveis, regra, prazo, autorização e conferência |
| Premiação | política, elegibilidade, incidência tributária, aprovação e comunicação |
| PLR | comissão de PLR, metas, elegíveis, desligados, proporcionalidade, acordo, sindicato e pagamento |
| Bônus anual | metas, pesos, atingimento, elegibilidade, aprovação, cálculo e evidência |
| Retroativos | CCT, promoção, comissão, salário, decisão jurídica ou ajuste pontual |

---

## 23. Relações sindicais e CCT

### Objetivo
Controlar obrigações decorrentes de sindicatos, convenções coletivas, acordos, data-base, reajustes, pisos, contribuições e cláusulas especiais.

### Fluxo operacional
```mermaid
flowchart TD
    MAP["Mapear sindicato por CNPJ/unidade/categoria"]:::start
    MAP --> CCT["Monitorar CCT, data-base e cláusulas aplicáveis"]:::deci
    CCT --> IMP["Identificar impacto: reajuste, piso, benefícios, jornada, contribuição, PLR"]
    IMP --> FOL["Aplicar reflexos em folha, benefícios e contratos"]:::aten
    FOL --> COM["Comunicar gestores/colaboradores quando necessário"]
    COM --> ARQ["Arquivar CCT, acordo, cálculos e evidências"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Controles essenciais
| Tema | Controle |
|---|---|
| Sindicato aplicável | CNPJ, unidade, município, categoria e data-base |
| Reajuste salarial | percentual, piso, retroativo, diferenças e conferência |
| Contribuição assistencial | regra da CCT, oposição, desconto, comunicação e arquivo |
| Banco de horas | validade, acordo individual/coletivo, prazo e compensação |
| Jornada e feriados | cláusulas especiais, trabalho em sábado/domingo/feriado e compensações |
| PLR sindical | comissão, acordo, protocolo, metas, elegíveis e pagamento |
| Homologação | exigência sindical, CCT ou prática interna |
| Estabilidades | CIPA, acidente, gestante, pré-aposentadoria e cláusulas convencionais |

---

## 24. Fornecedores, notas fiscais e pagamentos

### Objetivo
Controlar fornecedores de RH/DP, faturas, notas fiscais, aprovações, pagamento, contestação e arquivo, evitando pagamento indevido ou falta de comprovação.

### Fluxo operacional
```mermaid
flowchart TD
    NF["Receber nota fiscal/fatura/boleto"]:::start
    NF --> VAL["Validar CNPJ, competência, contrato, vidas e valores"]:::deci
    VAL --> DIV{Há divergência?}
    DIV -->|Sim| CON["Contestar com fornecedor"]:::aten
    CON --> RET["Aguardar retorno e ajustar valor"]
    DIV -->|Não| APR["Aprovar tecnicamente"]
    RET --> APR
    APR --> FIN["Enviar para financeiro/pagamento"]
    FIN --> ARQ["Arquivar NF, aprovação e comprovante"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

### Checklist de conferência
| Item | Conferência |
|---|---|
| CNPJ | fornecedor correto, tomador correto e empresa correta do cluster |
| Competência | mês de referência, período de serviço e vencimento |
| Escopo | serviço contratado x serviço cobrado |
| Quantidade | vidas, usuários, exames, consultas, vales ou eventos cobrados |
| Valor | contrato, proposta, reajuste, imposto e desconto |
| Aprovação | responsável técnico e aprovação financeira |
| Evidência | nota, boleto, memória, e-mail, aprovação e comprovante |

---

## 25. Sistemas, acessos e perfis

### Objetivo
Garantir controle de acesso, segregação de funções, revisão periódica e bloqueio tempestivo em desligamentos ou movimentações.

### Sistemas críticos
| Sistema | Controle necessário |
|---|---|
| ADP / sistema de folha | criação, perfil, alteração, revisão e exclusão |
| SSA | aprovadores, operadores, fluxo de pagamento e logs |
| Pipefy | etapas, responsáveis, automações, permissões e histórico |
| BankManager | operadores, aprovadores, dupla validação e comprovantes |
| Sistema de ponto | gestores, colaboradores, escalas, permissões e relatórios |
| Portais de benefícios | movimentações, usuários autorizados, faturas e bases |
| eSocial/FGTS/DCTFWeb | certificado, procuração, perfil e evidências |
| Pastas de rede/SharePoint | acesso restrito, LGPD, documentos sensíveis e auditoria |

### Fluxo operacional
```mermaid
flowchart TD
    SOL["Solicitação de acesso, alteração ou exclusão"]:::start
    SOL --> APR["Validar aprovação e necessidade"]:::deci
    APR --> PERF["Definir perfil mínimo necessário"]
    PERF --> EXEC["Criar, alterar ou remover acesso"]
    EXEC --> LOG["Registrar evidência"]
    LOG --> REV["Revisão periódica de acessos"]:::aten
    REV --> ARQ["Arquivar controle de acesso"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

---

## 26. LGPD, arquivo e retenção documental

### Objetivo
Controlar coleta, uso, armazenamento, compartilhamento e descarte de documentos e dados pessoais/sensíveis tratados pelo DP/RH.

### Regras principais
- Coletar apenas documentos necessários para a finalidade trabalhista, previdenciária, fiscal, contratual ou regulatória.
- Restringir acesso a dados sensíveis, especialmente saúde, ASO, atestados, PCD, dependentes, biometria e documentos médicos.
- Compartilhar dados com fornecedores apenas quando houver finalidade legítima e necessidade operacional.
- Evitar envio de documentos sensíveis por canais abertos ou sem controle.
- Manter trilha de evidência para solicitações, alterações, exclusões e compartilhamentos relevantes.
- Definir prazo de retenção por tipo documental conforme obrigação legal, defesa em processos e política interna.

### Matriz documental sugerida
| Documento | Acesso | Evidência/guarda |
|---|---|---|
| Documentos admissionais | DP restrito | pasta individual/checklist |
| Contrato/aditivos | DP/RH autorizado | arquivo funcional |
| ASO/atestados | acesso restrito | pasta sensível segregada |
| Benefícios/dependentes | DP/benefícios | base e comprovantes |
| Folha/recibos | DP/financeiro autorizado | competência e CNPJ |
| Rescisão | DP/RH/jurídico quando necessário | dossiê rescisório |
| Ponto | DP/gestor autorizado | espelho e relatórios |
| Fichas de EPI/treinamentos | DP/SST | dossiê SST |

---

## 27. Indicadores, auditoria e melhoria contínua

### Objetivo
Transformar o mapa operacional em gestão à vista, com indicadores de risco, produtividade, qualidade, prazos e reincidência.

### Indicadores recomendados
| Indicador | Fórmula / leitura | Objetivo |
|---|---|---|
| Erros de folha | quantidade e valor por competência | reduzir retrabalho e risco financeiro |
| Inputs fora do prazo | inputs atrasados / total de inputs | controlar disciplina operacional |
| Outliers críticos | variações atípicas por pessoa/rubrica | prevenir pagamento incorreto |
| Admissões no prazo | admissões completas antes da entrada / total | evitar admissão incompleta |
| Rescisões no prazo | rescisões pagas dentro do prazo / total | evitar multa e passivo |
| ASOs vencidos | exames vencidos por tipo/unidade | reduzir risco SST |
| Férias vencidas | casos em risco de dobra | evitar passivo trabalhista |
| Ponto pendente | colaboradores com exceção / total | reduzir HE/faltas indevidas |
| Benefícios divergentes | divergências em fatura/base | evitar cobrança indevida |
| Chamados por SLA | chamados dentro do SLA / total | medir atendimento |
| Encargos no prazo | guias pagas no prazo / total | evitar multa/juros |
| Risco por CNPJ | volume de exceções por empresa | priorizar ação corretiva |

### Auditoria mensal sugerida
| Frente | Conferência |
|---|---|
| Folha | rubricas críticas, líquidos, variações, admissões, desligamentos e férias |
| Encargos | INSS, FGTS, IRRF, DCTFWeb, eSocial e comprovantes |
| Benefícios | vidas, faturas, exclusões, admitidos, desligados e descontos |
| Ponto | HE, faltas, intervalos, alterações manuais e banco de horas |
| SST | ASOs, PGR, PCMSO, EPI, treinamentos e CAT |
| Documentos | dossiês, contratos, aditivos, rescisões e arquivos sensíveis |

---

## 28. Contingência, backup e continuidade operacional

### Objetivo
Garantir continuidade das rotinas críticas quando houver ausência, férias, desligamento, falha sistêmica, indisponibilidade de fornecedor ou atraso de input.

### Regras de continuidade
- Todo processo crítico deve ter titular, backup e evidência do passo a passo.
- Processos com prazo legal não podem depender de uma única pessoa.
- Sistemas, links, layouts, fornecedores, prazos e contatos devem estar documentados.
- Em caso de falha sistêmica, deve existir plano alternativo: planilha de contingência, cálculo manual, abertura de chamado e comunicação formal.
- O fechamento da folha deve ter checklist de substituição com etapas mínimas obrigatórias.

### Processos críticos com backup obrigatório
| Processo | Risco se não houver backup |
|---|---|
| Fechamento da folha | atraso ou erro de pagamento |
| Arquivo bancário | não pagamento de salários/rescisões/férias |
| Encargos | multa, juros e pendência fiscal |
| Rescisão | multa por atraso e passivo trabalhista |
| Admissão | início irregular ou sem ASO |
| Benefícios | colaborador sem cobertura ou cobrança indevida |
| Ponto | desconto indevido, HE indevida ou passivo |
| SST | ASO vencido, risco legal e acidente não tratado |
| Fornecedores | nota vencida, serviço suspenso ou pagamento incorreto |

---

## 29. Matriz operacional pré-RACI

Antes de aplicar a RACI, cada atividade deve possuir pelo menos os campos abaixo.

| Campo | Finalidade |
|---|---|
| Macroprocesso | bloco principal do mapa |
| Atividade | ação executável, não apenas tema |
| Gatilho | evento que inicia a atividade |
| Prazo | data limite ou SLA |
| Sistema | ferramenta onde ocorre a execução |
| Evidência | prova do que foi feito |
| Risco | impacto se falhar |
| Responsável atual | pessoa que executa hoje |
| Backup | pessoa que assume em ausência |

---

## 30. RACI — Matriz preliminar de responsabilidades

### Legenda
| Sigla | Significado | Interpretação prática |
|---|---|---|
| R | Responsible | Executa a atividade |
| A | Accountable | Responde pelo resultado final e aprova |
| C | Consulted | Deve ser consultado antes ou durante a execução |
| I | Informed | Deve ser informado do andamento ou conclusão |

### Premissas da RACI
- A matriz abaixo é uma versão preliminar para validação com Jair, Eduarda, Sabrina e Jameson.
- Quando houver impacto em folha, encargos, banco, rescisão ou pagamento, deve existir um responsável técnico final pela conferência.
- Quando houver impacto em SST, ASO, PGR, PCMSO, EPI, CAT ou treinamentos obrigatórios, Jameson deve ser tratado como responsável técnico ou consultado obrigatório.
- Quando houver impacto em ponto, jornada, férias, desligamento ou movimentação, o gestor deve ser envolvido como responsável pela informação operacional e aprovação da realidade do time.
- Fornecedor não deve ser dono do processo interno; fornecedor executa serviço contratado, mas o controle interno permanece com RH/DP.

### RACI consolidada
| Macroprocesso | Atividade crítica | Jair | Eduarda | Sabrina | Jameson | Anderson | Gestor | Fornecedor |
|---|---|---|---|---|---|---|---|---|
| Governança DP/RH | Controlar entrada, status e SLA das demandas | C | R | R | C | A | I | I |
| Governança DP/RH | Classificar criticidade e escalonar riscos | C | R | R | C | A | C | I |
| Admissão | Receber gatilho de carta oferta aceita | I | R | C | I | A | I | I |
| Admissão | Enviar boas-vindas e checklist | I | R | C | I | A | I | I |
| Admissão | Conferir documentação admissional | C | R | C | I | A | I | I |
| Admissão | Validar ASO admissional apto | I | R | C | C | A | I | R |
| Admissão | Cadastrar colaborador em sistema/folha | R | R | C | I | A | I | I |
| Admissão | Incluir benefícios iniciais | C | R | R | I | A | I | R |
| Admissão | Cadastrar ponto, escala e gestor aprovador | C | R | C | I | A | C | I |
| Admissão | Controlar integração obrigatória e certificados | I | R | C | C | A | C | C |
| Movimentações | Alteração salarial, promoção ou mérito | R | C | C | I | A | C | I |
| Movimentações | Alteração de cargo, função ou CBO | C | R | C | C | A | C | I |
| Movimentações | Alteração de jornada, escala ou local | C | R | C | C | A | C | I |
| Movimentações | Alteração de centro de custo ou gestor | C | R | C | I | A | C | I |
| Movimentações | Alteração de dependentes/dados bancários | C | R | C | I | A | I | I |
| Transferência CNPJs | Receber solicitação formal de transferência | C | R | C | I | A | C | I |
| Transferência CNPJs | Validar impacto trabalhista, folha e benefícios | R | C | C | C | A | C | I |
| Transferência CNPJs | Atualizar cadastro, CNPJ, centro de custo e gestor | R | R | C | I | A | C | I |
| Transferência CNPJs | Migrar férias, banco de horas e histórico | R | C | C | I | A | C | I |
| Transferência CNPJs | Conferir reflexo em folha e encargos | R | C | I | I | A | I | I |
| Férias | Planejar férias vencidas e a vencer | C | R | C | I | A | C | I |
| Férias | Validar solicitação, saldo, abono e prazo legal | R | R | C | I | A | C | I |
| Férias | Calcular férias nas janelas fixas | R | C | I | I | A | I | I |
| Férias | Gerar aviso/recibo e controlar assinatura | C | R | C | I | A | I | I |
| Férias | Conferir pagamento e lançamento em folha | R | C | I | I | A | I | I |
| Desligamento | Receber gatilho e checklist de desligamento | R | R | C | I | A | C | I |
| Desligamento | Checar estabilidade e risco trabalhista | C | C | I | C | A | C | C |
| Desligamento | Processar cálculo rescisório | R | C | I | I | A | I | I |
| Desligamento | Solicitar ASO demissional | I | R | C | C | A | C | R |
| Desligamento | Coletar materiais, acessos e devoluções | I | R | C | I | A | C | C |
| Desligamento | Apurar comissões de desligados D+2 | R | C | C | I | A | C | C |
| Desligamento | Enviar eSocial/FGTS rescisório e conferir guias | R | C | I | I | A | I | I |
| Desligamento | Cancelar benefícios | C | R | R | I | A | I | R |
| Folha mensal | Abrir competência e calendário de fechamento | R | C | C | I | A | I | I |
| Folha mensal | Coletar e validar inputs mensais | R | R | R | I | A | C | C |
| Folha mensal | Importar/lançar rubricas | R | C | C | I | A | I | I |
| Folha mensal | Calcular folha preliminar | R | I | I | I | A | I | I |
| Folha mensal | Conferir outliers e variações | R | C | C | I | A | I | I |
| Folha mensal | Validar líquido final e folhas por área | R | C | C | I | A | I | I |
| Folha mensal | Gerar arquivo bancário | R | I | I | I | A | I | I |
| Folha mensal | Subir BankManager / aprovações SSA/Pipefy | R | I | I | I | A | I | I |
| Folha mensal | Arquivar folha final e comprovantes | R | C | C | I | A | I | I |
| Folha complementar | Validar gatilho e autorização | R | C | C | I | A | C | I |
| Folha complementar | Calcular diferenças e incidências | R | I | I | I | A | I | I |
| Folha complementar | Pagar e arquivar comprovantes | R | I | I | I | A | I | I |
| Quinzenal | Controlar optantes | C | R | C | I | A | I | I |
| Quinzenal | Calcular e pagar dia 15 | R | C | I | I | A | I | I |
| Quinzenal | Descontar corretamente na folha mensal | R | I | I | I | A | I | I |
| Encargos | Conferir eSocial e totalizadores | R | I | I | I | A | I | I |
| Encargos | Conferir INSS/DCTFWeb | R | I | I | I | A | I | I |
| Encargos | Conferir FGTS Digital mensal/rescisório | R | I | I | I | A | I | I |
| Encargos | Conferir IRRF e bases tributáveis | R | I | I | I | A | I | I |
| Encargos | Emitir guias e arquivar comprovantes | R | I | I | I | A | I | I |
| Benefícios | Atualizar bases mensais de benefícios | C | R | R | I | A | I | R |
| Benefícios | Conferir faturas de saúde/odonto/seguro | C | R | R | I | A | I | R |
| Benefícios | Comprar VT/VR/VA | C | R | R | I | A | I | R |
| Benefícios | Lançar descontos/copay/consignado | R | C | R | I | A | I | C |
| Benefícios | Tratar contestação com fornecedor | I | R | R | I | A | I | C |
| Ponto/Jornada | Cadastrar escala e regra de ponto | C | R | C | I | A | C | I |
| Ponto/Jornada | Cobrar marcações e ajustes pendentes | C | R | C | I | A | R | I |
| Ponto/Jornada | Validar horas extras, faltas e atrasos | C | R | C | I | A | R | I |
| Ponto/Jornada | Fechar ponto para folha | R | R | C | I | A | C | I |
| Ponto/Jornada | Controlar banco de horas | R | C | C | I | A | C | I |
| Afastamentos | Receber e registrar atestados/licenças | C | R | C | C | A | I | I |
| Afastamentos | Avaliar impacto em folha e benefícios | R | C | C | C | A | I | I |
| Afastamentos | Controlar afastamento INSS e retorno | R | C | C | C | A | I | C |
| Afastamentos | Registrar eSocial quando aplicável | R | C | I | C | A | I | I |
| Variáveis | Receber bases de comissão/bônus/PLR | R | C | C | I | A | C | C |
| Variáveis | Validar elegibilidade e aprovação | R | C | C | I | A | C | C |
| Variáveis | Lançar/calcular valores na folha | R | I | I | I | A | I | I |
| Variáveis | Arquivar base, aprovação e memória | R | C | C | I | A | I | I |
| Relações sindicais | Mapear CCT/sindicato por CNPJ | C | C | I | I | A/R | I | C |
| Relações sindicais | Aplicar reajuste, piso e retroativo | R | C | I | I | A | I | I |
| Relações sindicais | Controlar contribuição/oposição | R | R | C | I | A | I | C |
| Relações sindicais | Controlar PLR sindical/acordo | C | C | I | I | A/R | C | C |
| SST | Controlar ASOs admissionais/periódicos/demissionais | I | R | C | A/R | C | C | R |
| SST | Controlar PGR, PCMSO e LTCAT | I | C | I | A/R | C | I | R |
| SST | Controlar EPI, CIPA, treinamentos e CAT | I | C | I | A/R | C | C | R |
| SST | Avaliar eventos SST/eSocial | C | I | I | R | A | I | C |
| Fornecedores | Receber e conferir notas/faturas | C | R | R | C | A | I | C |
| Fornecedores | Aprovar tecnicamente valores | C | R | R | C | A | I | C |
| Fornecedores | Contestar divergências | I | R | R | C | A | I | C |
| Sistemas/Acessos | Solicitar/criar/alterar acessos | C | R | C | C | A | I | C |
| Sistemas/Acessos | Revisar acessos periodicamente | C | R | C | C | A | I | C |
| Sistemas/Acessos | Bloquear acessos no desligamento | I | R | C | I | A | C | C |
| LGPD/Arquivo | Definir acesso restrito e guarda documental | C | R | C | C | A | I | I |
| LGPD/Arquivo | Arquivar documentos sensíveis corretamente | C | R | R | C | A | I | I |
| Indicadores | Atualizar indicadores de folha/DP | R | C | C | C | A | I | I |
| Indicadores | Apresentar riscos e plano de ação | C | C | C | C | A/R | C | I |
| Contingência | Definir titular e backup por processo | C | C | C | C | A/R | I | I |
| Contingência | Manter passo a passo operacional atualizado | R | R | R | R | A | I | I |

### Leitura executiva da RACI
- Jair aparece como eixo técnico de folha, encargos, pagamento, conferência, diferenças, quinzenal e impactos financeiros.
- Eduarda aparece como eixo operacional de admissão, cadastro, férias, desligamento, ponto, benefícios e controle documental.
- Sabrina aparece como apoio forte em benefícios, inputs, conferências, faturas, bases mensais e rotinas administrativas.
- Jameson aparece como eixo técnico de SST, ASO, PGR, PCMSO, EPI, CAT, treinamentos e riscos ocupacionais.
- Anderson aparece como accountable geral, responsável por aprovar governança, critério, prioridade, risco, fechamento final e desenho do modelo.
- Gestor deve ser incluído principalmente em ponto, jornada, férias, desligamento, movimentações, horas extras e validação da realidade operacional.
- Fornecedor executa parte do serviço, mas não substitui o controle interno do DP/RH.

### Pontos que devem ser validados em reunião
| Tema | Pergunta de validação |
|---|---|
| Folha | Jair será o responsável técnico final por cálculo, encargos e banco? |
| Benefícios | Sabrina assume benefícios como execução principal ou apoio da Eduarda? |
| Admissão | Eduarda permanece como dona operacional da entrada e checklist? |
| SST | Jameson assume o A técnico de SST ou apenas R técnico com Anderson como A? |
| Ponto | Quem cobra gestor e quem fecha para folha? |
| Comissões | Quem centraliza bases de comissão fora do fluxo? |
| Fornecedores | Quem aprova tecnicamente faturas antes do financeiro? |
| Backup | Quem substitui cada pessoa em férias ou ausência? |

---

## 31. Próxima etapa recomendada

A próxima etapa é transformar esta matriz em uma planilha operacional com filtros por macroprocesso, responsável, criticidade, prazo, sistema e evidência. O modelo mínimo recomendado é:

| Macroprocesso | Atividade | Gatilho | Prazo | Sistema | Evidência | Risco | Jair | Eduarda | Sabrina | Jameson | Anderson | Gestor | Fornecedor | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Com isso, o mapeamento deixa de ser apenas descritivo e passa a funcionar como ferramenta real de gestão, auditoria e distribuição de responsabilidade.

---

Anderson Marinho | Igarapé Digital
