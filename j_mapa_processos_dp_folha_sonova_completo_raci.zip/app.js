/* ============================================================
   Mapa de Processos DP e Folha — Sonova
   Visualizador de Markdown + Mermaid (sem dependencia de 'marked')
   Padrao de arquitetura: HROps Dashboard
   ============================================================ */

var MD_DEFAULT = 'mapa_processos_dp_folha_sonova.md';
var LS_KEY     = 'sonova_mapa_md_v1';

/* estado central */
var diagramCodes = [];   // array de string com o fonte Mermaid de cada diagrama
var sections     = [];
var mermaidReady = false;
var presOn       = false;
var presIdx      = 0;
var currentMd    = '';   // copia editavel do markdown em memoria

function $(id){ return document.getElementById(id); }

/* ---------- banner de aviso ---------- */
function showBanner(msg){
  var b = $('banner');
  b.textContent = msg + '  (clique para fechar)';
  b.hidden = false;
}
function hideBanner(){ $('banner').hidden = true; }

/* ---------- utilidades ---------- */
function escapeHtml(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
                  .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function slugify(t){
  return (t||'sec').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'') || 'sec';
}
function inline(t){
  t = escapeHtml(t);
  t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
  t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  return t;
}

/* ---------- parser de markdown proprio ---------- */
function normalizeCollapsedMarkdownTables(md){
  var rawLines = String(md || '').replace(/\r\n/g,'\n').split('\n');
  var out = [];

  rawLines.forEach(function(line){
    var txt = String(line || '');
    var trimmed = txt.trim();

    // Corrige tabelas coladas em uma única linha, comum quando o conteúdo vem de editor/chat:
    // | A | B | C | |---|---|---| | x | y | z |
    if(trimmed.indexOf('|') >= 0 && /\|\s*:?-{3,}:?\s*\|/.test(trimmed)){
      var cells = trimmed
        .split('|')
        .map(function(c){ return c.trim(); })
        .filter(function(c){ return c !== ''; });

      var sepStart = -1;
      for(var i=0; i<cells.length; i++){
        if(/^:?-{3,}:?$/.test(cells[i])){ sepStart = i; break; }
      }

      if(sepStart > 0){
        var colCount = 0;
        while((sepStart + colCount) < cells.length && /^:?-{3,}:?$/.test(cells[sepStart + colCount])){
          colCount++;
        }

        if(colCount > 0){
          var header = cells.slice(Math.max(0, sepStart - colCount), sepStart);
          var bodyCells = cells.slice(sepStart + colCount);

          if(header.length === colCount){
            out.push('| ' + header.join(' | ') + ' |');
            out.push('| ' + Array(colCount).fill('---').join(' | ') + ' |');

            for(var r=0; r<bodyCells.length; r += colCount){
              var row = bodyCells.slice(r, r + colCount);
              while(row.length < colCount) row.push('');
              out.push('| ' + row.join(' | ') + ' |');
            }
            return;
          }
        }
      }
    }

    out.push(line);
  });

  return out.join('\n');
}

function isTableSeparator(line){
  return /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(String(line || ''));
}

function isTableRow(line){
  var t = String(line || '').trim();
  return t.indexOf('|') >= 0 && /^\|.*\|$/.test(t);
}

function isMarkdownTableStart(lines, idx){
  if(idx + 1 >= lines.length) return false;
  return isTableRow(lines[idx]) && isTableSeparator(lines[idx + 1]);
}

function splitTableRow(row){
  return String(row || '')
    .trim()
    .replace(/^\|/, '')
    .replace(/\|$/, '')
    .split('|')
    .map(function(c){ return c.trim(); });
}

function renderMarkdownTable(lines, startIdx){
  var headers = splitTableRow(lines[startIdx]);
  var html = [];
  html.push('<div class="table-wrapper"><table class="md-table"><thead><tr>');
  headers.forEach(function(h){ html.push('<th>' + inline(h) + '</th>'); });
  html.push('</tr></thead><tbody>');

  var i = startIdx + 2;
  while(i < lines.length && isTableRow(lines[i])){
    var cells = splitTableRow(lines[i]);
    html.push('<tr>');
    headers.forEach(function(_h, cidx){
      html.push('<td>' + inline(cells[cidx] || '') + '</td>');
    });
    html.push('</tr>');
    i++;
  }

  html.push('</tbody></table></div>');
  return { html: html.join(''), next: i };
}

function mdToHtml(md){
  diagramCodes = [];
  md = normalizeCollapsedMarkdownTables(md);
  var lines = String(md).replace(/\r\n/g,'\n').split('\n');
  var html = [];
  var i = 0, n = lines.length;

  function flushPara(buf){ if(buf.length){ html.push('<p>'+inline(buf.join(' '))+'</p>'); } }

  while(i < n){
    var line = lines[i];

    // bloco de codigo cercado por ```
    var fence = line.match(/^```\s*(\S*)/);
    if(fence){
      var lang = fence[1] || '';
      var code = []; i++;
      while(i < n && !/^```/.test(lines[i])){ code.push(lines[i]); i++; }
      i++; // pula o fechamento
      var raw = code.join('\n');
      if(lang.trim() === 'mermaid'){
        var idx = diagramCodes.length;
        diagramCodes.push(raw);
        html.push('<figure class="diagram">'
                + '<div class="diagram-target" data-idx="'+idx+'"></div>'
                + '<button class="exp" type="button" data-idx="'+idx+'">Ampliar</button>'
                + '</figure>');
      } else {
        html.push('<pre><code>'+escapeHtml(raw)+'</code></pre>');
      }
      continue;
    }

    // regra horizontal
    if(/^---+\s*$/.test(line)){ html.push('<hr>'); i++; continue; }

    // titulos
    var h = line.match(/^(#{1,4})\s+(.*)$/);
    if(h){ var lvl = h[1].length; html.push('<h'+lvl+'>'+inline(h[2].trim())+'</h'+lvl+'>'); i++; continue; }

    // tabela markdown
    if(isMarkdownTableStart(lines, i)){
      var table = renderMarkdownTable(lines, i);
      html.push(table.html);
      i = table.next;
      continue;
    }

    // listas
    if(/^\s*[-*]\s+/.test(line)){
      var items = [];
      while(i < n && /^\s*[-*]\s+/.test(lines[i])){
        items.push('<li>'+inline(lines[i].replace(/^\s*[-*]\s+/,''))+'</li>');
        i++;
      }
      html.push('<ul>'+items.join('')+'</ul>');
      continue;
    }

    // linha em branco
    if(/^\s*$/.test(line)){ i++; continue; }

    // paragrafo (acumula ate linha em branco/especial)
    var buf = [];
    while(i < n && !/^\s*$/.test(lines[i]) && !/^```/.test(lines[i])
          && !/^#{1,4}\s/.test(lines[i]) && !/^---+\s*$/.test(lines[i])
          && !isMarkdownTableStart(lines, i)
          && !/^\s*[-*]\s+/.test(lines[i])){
      buf.push(lines[i].trim()); i++;
    }
    flushPara(buf);
  }
  return html.join('\n');
}

/* ---------- agrupa conteudo em secoes por <h2> ---------- */
function groupSections(){
  var content = $('content');
  var kids = Array.prototype.slice.call(content.childNodes);
  var frag = document.createDocumentFragment();
  var out = [];
  var cur = null;

  function newSec(title){
    var s = document.createElement('section');
    s.className = 'doc-section';
    s.dataset.title = title;
    s.id = slugify(title);
    out.push(s); frag.appendChild(s); cur = s;
  }

  var h1 = content.querySelector('h1');
  newSec(h1 ? 'Início e legenda' : 'Apresentação');

  kids.forEach(function(node){
    if(node.nodeType === 3){ if(node.textContent.trim()) cur.appendChild(node); return; }
    if(node.nodeType !== 1) return;
    var tag = node.tagName;
    if(tag === 'HR') return;
    if(tag === 'H2'){ newSec(node.textContent.trim()); cur.appendChild(node); return; }
    cur.appendChild(node);
  });

  content.innerHTML = '';
  content.appendChild(frag);
  return out;
}

/* ---------- injeta e renderiza diagramas ---------- */
function injectDiagrams(){
  var targets = document.querySelectorAll('.diagram-target');
  targets.forEach(function(t){
    var i = t.dataset.idx;
    if(mermaidReady){
      var d = document.createElement('div');
      d.className = 'mermaid';
      d.textContent = diagramCodes[i];   // textContent preserva <br/>, -->, aspas
      t.appendChild(d);
    } else {
      var pre = document.createElement('pre');
      pre.className = 'diagram-fallback';
      var c = document.createElement('code');
      c.textContent = diagramCodes[i];
      pre.appendChild(c); t.appendChild(pre);
      var b = t.parentNode.querySelector('.exp');
      if(b) b.style.display = 'none';
    }
  });
  if(mermaidReady){
    // garante que as fontes ja estejam carregadas antes de o Mermaid medir as caixas,
    // senao o texto e medido com fonte de fallback (mais estreita) e estoura/corta.
    var fontsReady = Promise.resolve();
    if(document.fonts){
      try{ document.fonts.load('400 14px Roboto'); document.fonts.load('500 14px Roboto'); document.fonts.load('700 16px Rufina'); }catch(_){}
      if(document.fonts.ready) fontsReady = document.fonts.ready;
    }
    return fontsReady.then(function(){
      return mermaid.run({ querySelector:'.mermaid' });
    }).then(function(){
      injectRoundedFilter();
    }).catch(function(e){
      console.error('Mermaid:', e);
      showBanner('Alguns diagramas não puderam ser desenhados; verifique a sintaxe do .md.');
    });
  }
  return Promise.resolve();
}

/* ---------- indice lateral + scroll-spy ---------- */
function buildTOC(){
  var list = $('toc-list');
  list.innerHTML = '';
  sections.forEach(function(s){
    var a = document.createElement('a');
    a.href = '#'+s.id;
    a.textContent = s.dataset.title;
    a.addEventListener('click', function(e){
      e.preventDefault();
      s.scrollIntoView({behavior:'smooth', block:'start'});
    });
    list.appendChild(a);
  });
  var links = Array.prototype.slice.call(list.children);
  var obs = new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(en.isIntersecting){
        var id = en.target.id;
        links.forEach(function(l){ l.classList.toggle('active', l.getAttribute('href') === '#'+id); });
      }
    });
  }, { rootMargin:'-64px 0px -70% 0px', threshold:0 });
  sections.forEach(function(s){ obs.observe(s); });
}

/* ---------- expandir diagrama (zoom) ----------
   Redimensiona o SVG pelas dimensoes reais (vetor nitido) e move por translate.
   Nao usa transform: scale, que rasteriza os rotulos foreignObject e borra.   */
var zScale=1, panX=0, panY=0, baseW=0, baseH=0, zClone=null, dragging=false, sx=0, sy=0;

function applyZoom(){
  if(zClone){
    zClone.style.width  = (baseW*zScale)+'px';
    zClone.style.height = (baseH*zScale)+'px';
  }
  $('zoom-stage').style.transform = 'translate('+panX+'px,'+panY+'px)';
}
function fitZoom(){
  var body = $('zoom-body');
  if(!zClone || !baseW){ zScale=1; panX=0; panY=0; applyZoom(); return; }
  var bw = body.clientWidth, bh = body.clientHeight;
  var k = Math.min(bw/baseW, bh/baseH) * 0.95;
  zScale = (isFinite(k) && k>0) ? k : 1;
  panX = (bw - baseW*zScale)/2;
  panY = (bh - baseH*zScale)/2;
  applyZoom();
}
function zoomAround(factor, mx, my){
  var cx = (mx - panX)/zScale, cy = (my - panY)/zScale;
  var ns = Math.max(0.05, Math.min(zScale*factor, 14));
  panX = mx - cx*ns; panY = my - cy*ns; zScale = ns; applyZoom();
}
function zoomCenter(factor){
  var body = $('zoom-body');
  zoomAround(factor, body.clientWidth/2, body.clientHeight/2);
}
function openZoom(idx){
  var fig = document.querySelector('.diagram-target[data-idx="'+idx+'"]');
  var svg = fig ? fig.querySelector('svg') : null;
  if(!svg) return;
  var sec = fig.closest('.doc-section');
  $('zoom-title').textContent = sec ? sec.dataset.title : 'Diagrama';
  var stage = $('zoom-stage');
  stage.innerHTML = '';
  var clone = svg.cloneNode(true);
  var vb = clone.viewBox && clone.viewBox.baseVal ? clone.viewBox.baseVal : null;
  var rect = svg.getBoundingClientRect();
  baseW = (vb && vb.width)  ? vb.width  : (rect.width  || 800);
  baseH = (vb && vb.height) ? vb.height : (rect.height || 600);
  clone.removeAttribute('style');
  clone.removeAttribute('width');
  clone.removeAttribute('height');
  clone.style.display = 'block';
  clone.style.maxWidth = 'none';
  zClone = clone;
  stage.appendChild(clone);
  $('zoom-overlay').hidden = false;
  requestAnimationFrame(fitZoom);
}
function closeZoom(){ $('zoom-overlay').hidden = true; zClone = null; }
function setupZoom(){
  $('content').addEventListener('click', function(e){
    var b = e.target.closest ? e.target.closest('.exp') : null;
    if(b) openZoom(b.dataset.idx);
  });
  $('zoom-overlay').addEventListener('click', function(e){
    var b = e.target.closest ? e.target.closest('button[data-z]') : null;
    if(b){
      var z = b.dataset.z;
      if(z==='in')   { zoomCenter(1.25); }
      if(z==='out')  { zoomCenter(1/1.25); }
      if(z==='reset'){ fitZoom(); }
      if(z==='close'){ closeZoom(); }
      return;
    }
    if(e.target.id === 'zoom-overlay') closeZoom();
  });
  var body = $('zoom-body');
  body.addEventListener('wheel', function(e){
    e.preventDefault();
    var r = body.getBoundingClientRect();
    zoomAround(e.deltaY < 0 ? 1.12 : 1/1.12, e.clientX - r.left, e.clientY - r.top);
  }, {passive:false});
  body.addEventListener('pointerdown', function(e){ dragging=true; sx=e.clientX-panX; sy=e.clientY-panY; body.classList.add('grabbing'); try{body.setPointerCapture(e.pointerId);}catch(_){} });
  body.addEventListener('pointermove', function(e){ if(!dragging) return; panX=e.clientX-sx; panY=e.clientY-sy; applyZoom(); });
  body.addEventListener('pointerup',   function(){ dragging=false; body.classList.remove('grabbing'); });
}

/* ---------- modo apresentacao ---------- */
function enterPres(){
  if(!sections.length) return;
  presOn = true;
  document.body.classList.add('present-on');
  $('pres-bar').hidden = false;
  $('btn-present').classList.add('on');
  var vis = -1;
  for(var k=0;k<sections.length;k++){
    var r = sections[k].getBoundingClientRect();
    if(r.top >= 0 && r.top < window.innerHeight*0.6){ vis=k; break; }
  }
  showPres(vis >= 0 ? vis : 0);
}
function exitPres(){
  presOn = false;
  document.body.classList.remove('present-on');
  $('pres-bar').hidden = true;
  $('btn-present').classList.remove('on');
  sections.forEach(function(s){ s.classList.remove('pres-active'); });
  if(document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(function(){});
}
function showPres(i){
  presIdx = Math.max(0, Math.min(i, sections.length-1));
  sections.forEach(function(s,idx){ s.classList.toggle('pres-active', idx===presIdx); });
  $('pres-count').textContent = (presIdx+1)+' / '+sections.length;
  if(sections[presIdx]) sections[presIdx].scrollTop = 0;
}
function togglePres(){ presOn ? exitPres() : enterPres(); }
function toggleFull(){
  if(document.fullscreenElement){ if(document.exitFullscreen) document.exitFullscreen().catch(function(){}); }
  else if(document.documentElement.requestFullscreen){ document.documentElement.requestFullscreen().catch(function(){}); }
}

/* ---------- carga do documento ---------- */
function loadMarkdown(md, persist){
  currentMd = md;
  var content = $('content');
  content.innerHTML = mdToHtml(md);
  sections = groupSections();
  return injectDiagrams().then(function(){
    buildTOC();
    if(persist) localStorage.setItem(LS_KEY, md);
    $('drop').hidden = true;
    window.scrollTo(0,0);
  });
}
function showDrop(msg){ $('drop').hidden = false; $('drop-hint').textContent = msg || ''; }
function readFile(file){
  if(!file){ showDrop('Nenhum arquivo selecionado.'); return; }
  var r = new FileReader();
  r.onload  = function(){ var t=String(r.result||''); if(!t.trim()){ showDrop('Arquivo vazio.'); return; } loadMarkdown(t, true); };
  r.onerror = function(){ showDrop('Não foi possível ler o arquivo.'); };
  r.readAsText(file, 'UTF-8');
}

/* ---------- mermaid ---------- */
function loadScript(src){
  return new Promise(function(res){
    var s = document.createElement('script');
    s.src = src; s.onload=function(){res(true)}; s.onerror=function(){res(false)};
    document.head.appendChild(s);
  });
}
function ensureMermaid(){
  if(typeof mermaid !== 'undefined'){ mermaidReady = true; }
  return (mermaidReady ? Promise.resolve(true) : loadScript('mermaid.min.js')).then(function(){
    mermaidReady = (typeof mermaid !== 'undefined');
    if(mermaidReady){
      mermaid.initialize({
        startOnLoad:false, securityLevel:'loose', theme:'base',
        themeVariables:{
          fontFamily:"'Roboto', Arial, sans-serif",
          primaryColor:'#ffffff', primaryTextColor:'#003C64',
          primaryBorderColor:'#0083CA', lineColor:'#646464',
          tertiaryColor:'#ffffff', fontSize:'14px'
        },
        flowchart:{ htmlLabels:true, useMaxWidth:true, curve:'basis' }
      });
    } else {
      showBanner('Biblioteca de diagramas (Mermaid) não carregou — provável bloqueio de internet. Baixe "mermaid.min.js" e coloque na mesma pasta do index.html. O texto continua legível; os diagramas aparecem como código.');
    }
  });
}

/* ---------- boot ---------- */
function boot(){
  ensureMermaid().then(function(){
    var done = function(md){
      if(md){ loadMarkdown(md, false); }
      else { showDrop('Não encontrei o conteúdo. Carregue um arquivo .md.'); }
    };
    // 1) fetch (GitHub Pages / servidor) — versao canonica do .md
    var p;
    try{
      p = fetch(MD_DEFAULT, {cache:'no-store'}).then(function(res){
        if(res.ok) return res.text();
        return null;
      }).catch(function(){ return null; });
    }catch(e){ p = Promise.resolve(null); }

    p.then(function(t){
      if(t && (t.indexOf('```mermaid') >= 0 || t.trim().charAt(0) === '#')){ done(t); return; }
      // 2) conteudo embutido (file:// / offline)
      if(window.MAPA_MD && window.MAPA_MD.trim()){ done(window.MAPA_MD); return; }
      // 3) cache local
      var c = localStorage.getItem(LS_KEY);
      done(c || null);
    });
  });
}

/* ---------- SALVAR .MD ---------- */
function saveMd(){
  if(screenEditOn && typeof syncScreenTextToMd === 'function'){ syncScreenTextToMd(); }
  if(!currentMd){ showBanner('Nenhum conteúdo carregado para salvar.'); return; }
  var blob = new Blob([currentMd], {type:'text/markdown;charset=utf-8'});
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'mapa_processos_dp_folha_sonova.md';
  document.body.appendChild(a); a.click();
  setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

/* ---------- EDITOR INLINE DE NÓS ----------
   Estratégia:
   1. Duplo clique em qualquer .node do SVG Mermaid.
   2. Extrai o texto do foreignObject (htmlLabels) ou do texto do nó.
   3. Identifica qual bloco Mermaid (data-idx) contém aquele nó.
   4. Encontra a linha correspondente no fonte do diagrama.
   5. Abre modal de edição de texto.
   6. Ao confirmar: reescreve a linha no fonte, re-renderiza apenas aquele diagrama,
      atualiza currentMd.
*/

var _editCtx = null; // { idx, nodeId, originalLabel, lineKey }

function getNodeLabel(nodeEl){
  // foreignObject (htmlLabels=true)
  var fo = nodeEl.querySelector('foreignObject');
  if(fo){
    var inner = fo.querySelector('.nodeLabel');
    if(inner) return inner.innerHTML.trim();
    return fo.textContent.trim();
  }
  // texto simples
  var t = nodeEl.querySelector('text');
  if(t) return t.textContent.trim();
  return '';
}

/* Converte HTML de label (pode ter <br/>, <b>, etc.) em texto Mermaid
   (o Mermaid usa <br/> dentro de strings com aspas). */
function labelHtmlToMermaid(html){
  // Normaliza <br>, remove wrappers de <p> que o Mermaid pode gerar e evita salvar <p></p> no .md.
  return String(html || '')
    .replace(/<\/?p[^>]*>/gi,'')
    .replace(/<br\s*\/?>/gi,'<br/>')
    .replace(/&amp;/g,'&')
    .replace(/&lt;/g,'<')
    .replace(/&gt;/g,'>')
    .trim();
}

/* Extrai o ID do nó a partir do elemento SVG.
   O Mermaid adiciona classe "node" e um id="flowchart-NODEID-N" ao <g>. */
function getNodeId(nodeEl){
  var id = nodeEl.id || '';
  // formato: flowchart-NODEID-N  ou  root-0-NODEID-N
  var m = id.match(/flowchart-([A-Za-z0-9_]+)-\d+/) || id.match(/-([A-Za-z0-9_]+)-\d+$/);
  return m ? m[1] : null;
}

/* Localiza e substitui o label de um nó no fonte Mermaid.
   Suporta estilos:
     ID["label"]
     ID(["label"])
     ID(["label"]):::classe
     ID["label"]:::classe
   Onde label pode conter <br/>.
   Retorna o novo fonte ou null se não encontrou. */
function replaceLabelInSource(src, nodeId, newLabel){
  if(!nodeId) return null;
  // Regex: ID seguido de delimitadores de caixa Mermaid, captura o conteúdo
  // Suporta: ["..."], (["..."]), ("..."), ("...")  e variações
  var patterns = [
    // ID(["label"])  ou  ID(["label"]):::cls
    new RegExp('(\\b' + nodeId + '\\s*\\(\\["?)([^"\\]]+?)("?\\]\\))', 'g'),
    // ID["label"]  ou  ID["label"]:::cls
    new RegExp('(\\b' + nodeId + '\\s*\\[")([^"]+?)("\\])', 'g'),
    // ID("label")
    new RegExp('(\\b' + nodeId + '\\s*\\(")([^"]+?)("\\))', 'g'),
  ];
  var found = false;
  var result = src;
  for(var p=0; p<patterns.length; p++){
    if(patterns[p].test(result)){
      patterns[p].lastIndex = 0;
      result = result.replace(patterns[p], function(m, pre, _old, suf){
        found = true;
        return pre + newLabel + suf;
      });
      if(found) break;
    }
  }
  return found ? result : null;
}

/* Re-renderiza um único diagrama (substitui o SVG no lugar) */
function rerenderDiagram(idx){
  var target = document.querySelector('.diagram-target[data-idx="'+idx+'"]');
  if(!target) return Promise.resolve();
  // Remove div.mermaid anterior
  var old = target.querySelector('.mermaid');
  if(old) old.remove();
  var d = document.createElement('div');
  d.className = 'mermaid';
  d.textContent = diagramCodes[idx];
  target.appendChild(d);
  return mermaid.run({ nodes:[d] }).catch(function(e){ console.error('rerender:', e); });
}

/* Sincroniza diagramCodes[idx] de volta para currentMd */
function syncDiagramToMd(idx, newDiagramSrc){
  // Precisamos localizar o bloco ```mermaid ... ``` correspondente ao índice idx
  // no currentMd e substituí-lo.
  var count = -1;
  var result = currentMd.replace(/```mermaid\n([\s\S]*?)```/g, function(m, body){
    count++;
    if(count === idx) return '```mermaid\n' + newDiagramSrc + '\n```';
    return m;
  });
  currentMd = result;
  localStorage.setItem(LS_KEY, currentMd);
}

/* Abre o modal de edição */
function openNodeEdit(nodeEl, diagramIdx){
  var nodeId    = getNodeId(nodeEl);
  var labelHtml = getNodeLabel(nodeEl);
  var labelMd   = labelHtmlToMermaid(labelHtml);

  _editCtx = { idx: diagramIdx, nodeId: nodeId, labelHtml: labelHtml };

  var ta = $('node-edit-ta');
  ta.value = labelMd;
  $('node-edit-info').textContent = nodeId ? 'Nó: ' + nodeId : '';
  $('node-edit-overlay').hidden = false;
  setTimeout(function(){ ta.focus(); ta.select(); }, 80);
}
function closeNodeEdit(){
  $('node-edit-overlay').hidden = true;
  _editCtx = null;
}
function applyNodeEdit(){
  if(!_editCtx) return;
  var newLabel = $('node-edit-ta').value.trim();
  if(!newLabel){ showBanner('Texto não pode ser vazio.'); return; }

  var idx    = _editCtx.idx;
  var nodeId = _editCtx.nodeId;

  var newDiagramSrc = replaceLabelInSource(diagramCodes[idx], nodeId, newLabel);
  if(!newDiagramSrc){
    showBanner('Não foi possível localizar o nó "' + nodeId + '" no fonte do diagrama. Edite o .md diretamente.');
    closeNodeEdit();
    return;
  }

  diagramCodes[idx] = newDiagramSrc;
  syncDiagramToMd(idx, newDiagramSrc);
  closeNodeEdit();

  rerenderDiagram(idx).then(function(){
    // Reaplica CSS de contraste nos nós após re-render
    injectRoundedFilter();
  });
}

/* Injeta filtro SVG para arredondar polygons (losangos de decisão) */
function injectRoundedFilter(){
  document.querySelectorAll('figure.diagram svg, #zoom-stage svg').forEach(function(svg){
    if(svg.querySelector('#round-corners')) return;
    var defs = svg.querySelector('defs') || svg.insertBefore(document.createElementNS('http://www.w3.org/2000/svg','defs'), svg.firstChild);
    defs.innerHTML += '<filter id="round-corners" x="-5%" y="-5%" width="110%" height="110%">'
      + '<feMorphology operator="dilate" radius="2" in="SourceGraphic" result="e"/>'
      + '<feGaussianBlur stdDeviation="2" in="e" result="b"/>'
      + '<feComposite in="SourceGraphic" in2="b" operator="over"/>'
      + '</filter>';
  });
}

/* Configura listener de duplo clique nos diagramas para edição de nó */
function setupNodeEdit(){
  $('content').addEventListener('dblclick', function(e){
    // Encontra o elemento .node mais próximo
    var nodeEl = e.target;
    while(nodeEl && nodeEl !== this){
      if(nodeEl.classList && nodeEl.classList.contains('node')) break;
      nodeEl = nodeEl.parentElement;
    }
    if(!nodeEl || !nodeEl.classList || !nodeEl.classList.contains('node')) return;

    // Descobre o data-idx do diagrama pai
    var target = nodeEl.closest ? nodeEl.closest('.diagram-target') : null;
    if(!target){
      // Pode estar aninhado mais fundo; sobe pelo DOM
      var p = nodeEl;
      while(p && p !== document.body){
        if(p.classList && p.classList.contains('diagram-target')){ target = p; break; }
        p = p.parentElement;
      }
    }
    if(!target) return;
    var idx = parseInt(target.dataset.idx, 10);
    if(isNaN(idx)) return;

    e.preventDefault();
    e.stopPropagation();
    openNodeEdit(nodeEl, idx);
  });

  // Botões do modal
  $('node-edit-ok').addEventListener('click', applyNodeEdit);
  $('node-edit-cancel').addEventListener('click', closeNodeEdit);
  $('node-edit-close').addEventListener('click', closeNodeEdit);
  $('node-edit-overlay').addEventListener('click', function(e){
    if(e.target === this) closeNodeEdit();
  });
  $('node-edit-ta').addEventListener('keydown', function(e){
    if(e.key === 'Enter' && (e.ctrlKey || e.metaKey)){ e.preventDefault(); applyNodeEdit(); }
  });
}



/* ---------- EDITOR GERAL: texto, ordem e paleta Sonova ---------- */
var SONOVA_CLASSES = {
  start  : 'fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff',
  sub    : 'fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64',
  deci   : 'fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff',
  aten   : 'fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff',
  done   : 'fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff',
  date   : 'fill:#fff,stroke:#0083CA,stroke-width:2px,color:#0083CA',
  neutral: 'fill:#F2F2F2,stroke:#CCCCCC,stroke-width:1px,color:#003C64'
};
var _meState = { diagramIdx:0, selectedNodeId:null };

function decodeMermaidLabel(s){
  return String(s || '').replace(/<br\s*\/?\s*>/gi, '<br/>').replace(/\\"/g, '"');
}
function escapeMermaidLabel(s){
  return String(s || '').replace(/\r\n/g, '\n').replace(/\n/g, '<br/>').replace(/"/g, "'").trim();
}
function stripLabelForList(s){
  return decodeMermaidLabel(s).replace(/<br\/>/gi, ' / ').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
}
function diagramTitleByIdx(idx){
  var t = document.querySelector('.diagram-target[data-idx="'+idx+'"]');
  var s = t ? t.closest('.doc-section') : null;
  return s ? s.dataset.title : 'Diagrama ' + (idx + 1);
}
function getMermaidBlocksFromMd(md){
  var blocks = [];
  String(md || '').replace(/```mermaid\n([\s\S]*?)```/g, function(_m, body){ blocks.push(body.replace(/\n$/, '')); return _m; });
  return blocks;
}
function ensureSonovaClassDefs(src){
  var out = String(src || '').replace(/\s+$/,'');
  Object.keys(SONOVA_CLASSES).forEach(function(cls){
    var re = new RegExp('^\\s*classDef\\s+' + cls + '\\b', 'm');
    if(!re.test(out)) out += '\n    classDef ' + cls + ' ' + SONOVA_CLASSES[cls] + ';';
  });
  return out;
}
function refreshAllDiagramsFromMd(){
  diagramCodes = getMermaidBlocksFromMd(currentMd).map(ensureSonovaClassDefs);
  diagramCodes.forEach(function(src, idx){ syncDiagramToMd(idx, src); });
}
function extractNodesFromDiagram(src){
  var nodes = {}, order = [];
  var shape = /\b([A-Za-z][A-Za-z0-9_]*)\s*(\(\["([\s\S]*?)"\]\)|\["([\s\S]*?)"\]|\("([\s\S]*?)"\)|\(\[([^\]]*?)\]\)|\[([^\]]*?)\])(:::(\w+))?/g;
  String(src || '').split('\n').forEach(function(line){
    if(/^\s*classDef\b/.test(line) || /^\s*%%/.test(line)) return;
    var m;
    while((m = shape.exec(line)) !== null){
      var id = m[1];
      var label = m[3] || m[4] || m[5] || m[6] || m[7] || id;
      var cls = m[9] || findExplicitClass(src, id) || '';
      if(!nodes[id]){ nodes[id] = {id:id, label:decodeMermaidLabel(label), cls:cls}; order.push(id); }
      else { nodes[id].label = decodeMermaidLabel(label); if(cls) nodes[id].cls = cls; }
    }
  });
  return order.map(function(id){ return nodes[id]; });
}
function findExplicitClass(src, nodeId){
  var re = new RegExp('^\\s*class\\s+([^\\n;]+?)\\s+([A-Za-z][A-Za-z0-9_]*)\\s*;?', 'gm');
  var m;
  while((m = re.exec(src)) !== null){
    var ids = m[1].split(',').map(function(x){ return x.trim(); });
    if(ids.indexOf(nodeId) >= 0) return m[2];
  }
  return '';
}
function replaceNodeClassInSource(src, nodeId, newClass){
  var escaped = nodeId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var re = new RegExp('(\\b' + escaped + '\\s*(?:\\(\\["[\\s\\S]*?"\\]\\)|\\["[\\s\\S]*?"\\]|\\("[\\s\\S]*?"\\)|\\(\\[[^\\]]*?\\]\\)|\\[[^\\]]*?\\]))(:::[A-Za-z][A-Za-z0-9_]*)?', 'm');
  if(re.test(src)) return src.replace(re, '$1:::' + newClass);

  var classLine = new RegExp('(^\\s*class\\s+[^\\n;]*\\b' + escaped + '\\b[^\\n;]*\\s+)([A-Za-z][A-Za-z0-9_]*)(\\s*;?)', 'm');
  if(classLine.test(src)) return src.replace(classLine, '$1' + newClass + '$3');

  return src + '\n    class ' + nodeId + ' ' + newClass + ';';
}
function replaceLabelInSourceFlexible(src, nodeId, newLabel){
  var escaped = nodeId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var label = escapeMermaidLabel(newLabel);
  var patterns = [
    new RegExp('(\\b' + escaped + '\\s*\\(\\[")([\\s\\S]*?)("\\]\\))', 'm'),
    new RegExp('(\\b' + escaped + '\\s*\\[")([\\s\\S]*?)("\\])', 'm'),
    new RegExp('(\\b' + escaped + '\\s*\\(")([\\s\\S]*?)("\\))', 'm'),
    new RegExp('(\\b' + escaped + '\\s*\\(\\[)([^\\]]*?)(\\]\\))', 'm'),
    new RegExp('(\\b' + escaped + '\\s*\\[)([^\\]]*?)(\\])', 'm')
  ];
  for(var i=0;i<patterns.length;i++){
    if(patterns[i].test(src)) return src.replace(patterns[i], '$1' + label + '$3');
  }
  return null;
}
function getDiagramBusinessLines(src){
  var lines = String(src || '').split('\n');
  var out = [];
  lines.forEach(function(line, idx){
    var t = line.trim();
    if(!t || /^flowchart\b/.test(t) || /^graph\b/.test(t) || /^classDef\b/.test(t) || /^class\b/.test(t) || /^%%/.test(t)) return;
    if(t.indexOf('-->') >= 0 || /[A-Za-z][\w]*\s*(\(|\[)/.test(t)) out.push({idx:idx, text:line});
  });
  return out;
}
function moveDiagramLine(src, lineIdx, direction){
  var lines = String(src || '').split('\n');
  var business = getDiagramBusinessLines(src).map(function(x){ return x.idx; });
  var pos = business.indexOf(lineIdx);
  if(pos < 0) return src;
  var otherPos = pos + direction;
  if(otherPos < 0 || otherPos >= business.length) return src;
  var otherIdx = business[otherPos];
  var tmp = lines[lineIdx]; lines[lineIdx] = lines[otherIdx]; lines[otherIdx] = tmp;
  return lines.join('\n');
}
function applyDiagramSource(idx, newSrc){
  newSrc = ensureSonovaClassDefs(newSrc);
  diagramCodes[idx] = newSrc;
  syncDiagramToMd(idx, newSrc);
  return loadMarkdown(currentMd, true).then(function(){
    _meState.diagramIdx = Math.min(idx, diagramCodes.length - 1);
    buildMapEditorPanels();
  });
}
function openMapEditor(){
  refreshAllDiagramsFromMd();
  $('map-md-editor').value = currentMd || '';
  $('map-editor-overlay').hidden = false;
  buildMapEditorPanels();
}
function closeMapEditor(){ $('map-editor-overlay').hidden = true; }
function switchMapEditorTab(tab){
  document.querySelectorAll('.me-tab').forEach(function(b){ b.classList.toggle('active', b.dataset.tab === tab); });
  document.querySelectorAll('.me-panel').forEach(function(p){ p.classList.remove('active'); });
  var panel = $('me-panel-' + tab);
  if(panel) panel.classList.add('active');
  if(tab === 'texto') $('map-md-editor').value = currentMd || '';
}
function buildMapEditorPanels(){
  var sel = $('me-diagram-select');
  if(!sel) return;
  sel.innerHTML = '';
  diagramCodes.forEach(function(_src, idx){
    var opt = document.createElement('option');
    opt.value = String(idx);
    opt.textContent = (idx + 1) + '. ' + diagramTitleByIdx(idx);
    sel.appendChild(opt);
  });
  if(_meState.diagramIdx >= diagramCodes.length) _meState.diagramIdx = 0;
  sel.value = String(_meState.diagramIdx || 0);
  buildNodeList();
  buildOrderList();
}
function buildNodeList(){
  var idx = parseInt($('me-diagram-select').value || '0', 10);
  _meState.diagramIdx = idx;
  var nodes = extractNodesFromDiagram(diagramCodes[idx] || '');
  var list = $('me-node-list');
  list.innerHTML = '';
  if(!nodes.length){ list.innerHTML = '<div class="me-empty">Nenhuma caixa com texto foi encontrada neste diagrama.</div>'; return; }
  if(!_meState.selectedNodeId || !nodes.some(function(n){ return n.id === _meState.selectedNodeId; })) _meState.selectedNodeId = nodes[0].id;
  nodes.forEach(function(n){
    var item = document.createElement('button');
    item.type = 'button';
    item.className = 'me-item' + (n.id === _meState.selectedNodeId ? ' selected' : '');
    item.innerHTML = '<span class="me-swatch '+(n.cls || 'neutral')+'"></span><span><strong>'+escapeHtml(n.id)+'</strong><br>'+escapeHtml(stripLabelForList(n.label))+'</span>';
    item.addEventListener('click', function(){ _meState.selectedNodeId = n.id; buildNodeList(); });
    list.appendChild(item);
  });
  var chosen = nodes.filter(function(n){ return n.id === _meState.selectedNodeId; })[0] || nodes[0];
  $('me-node-label').value = chosen ? decodeMermaidLabel(chosen.label).replace(/<br\/>/gi, '\n') : '';
  $('me-node-class').value = chosen && SONOVA_CLASSES[chosen.cls] ? chosen.cls : 'neutral';
}
function buildOrderList(){
  var idx = parseInt($('me-diagram-select').value || '0', 10);
  var list = $('me-order-list');
  list.innerHTML = '';
  var lines = getDiagramBusinessLines(diagramCodes[idx] || '');
  if(!lines.length){ list.innerHTML = '<div class="me-empty">Nenhuma linha reordenável encontrada.</div>'; return; }
  lines.forEach(function(item, orderIdx){
    var row = document.createElement('div');
    row.className = 'me-order-item';
    var clean = item.text.trim().replace(/:::\w+/g, '').replace(/<br\s*\/?\s*>/gi, ' / ');
    row.innerHTML = '<div class="me-order-text"><strong>'+(orderIdx+1)+'</strong> '+escapeHtml(clean)+'</div>'
      + '<div class="me-order-actions"><button type="button" data-dir="-1">Subir</button><button type="button" data-dir="1">Descer</button></div>';
    row.querySelectorAll('button').forEach(function(btn){
      btn.addEventListener('click', function(){
        var dir = parseInt(btn.dataset.dir, 10);
        var newSrc = moveDiagramLine(diagramCodes[idx], item.idx, dir);
        applyDiagramSource(idx, newSrc);
      });
    });
    list.appendChild(row);
  });
}
function applyMdEditor(){
  var txt = $('map-md-editor').value;
  if(!txt || !txt.trim()){ showBanner('O texto do mapa não pode ficar vazio.'); return; }
  currentMd = txt;
  loadMarkdown(currentMd, true).then(function(){
    refreshAllDiagramsFromMd();
    buildMapEditorPanels();
    showBanner('Texto geral aplicado. Clique em Salvar .md para baixar a versão editada.');
  });
}
function applySelectedNodeFromEditor(){
  var idx = parseInt($('me-diagram-select').value || '0', 10);
  var nodeId = _meState.selectedNodeId;
  if(!nodeId){ showBanner('Selecione uma caixa antes de aplicar.'); return; }
  var label = $('me-node-label').value.trim();
  if(!label){ showBanner('Texto da caixa não pode ficar vazio.'); return; }
  var cls = $('me-node-class').value || 'neutral';
  var src = diagramCodes[idx] || '';
  var withLabel = replaceLabelInSourceFlexible(src, nodeId, label);
  if(!withLabel){ showBanner('Não foi possível localizar a caixa "' + nodeId + '" no fonte Mermaid.'); return; }
  var withClass = replaceNodeClassInSource(withLabel, nodeId, cls);
  applyDiagramSource(idx, withClass).then(function(){
    _meState.selectedNodeId = nodeId;
    showBanner('Caixa atualizada. Clique em Salvar .md para baixar a versão editada.');
  });
}
function setupMapEditor(){
  $('btn-map-editor').addEventListener('click', openMapEditor);
  $('map-editor-close').addEventListener('click', closeMapEditor);
  $('map-editor-overlay').addEventListener('click', function(e){ if(e.target === this) closeMapEditor(); });
  document.querySelectorAll('.me-tab').forEach(function(btn){ btn.addEventListener('click', function(){ switchMapEditorTab(btn.dataset.tab); }); });
  $('map-md-apply').addEventListener('click', applyMdEditor);
  $('me-diagram-select').addEventListener('change', function(){ _meState.diagramIdx = parseInt(this.value || '0', 10); _meState.selectedNodeId = null; buildNodeList(); buildOrderList(); });
  $('me-node-apply').addEventListener('click', applySelectedNodeFromEditor);
}



/* ---------- EDIÇÃO DIRETA EM TELA ----------
   Objetivo: permitir editar qualquer texto renderizado no documento
   sem abrir o editor de Markdown. Ao concluir, o HTML visível é
   convertido novamente para Markdown e salvo em currentMd/localStorage.
   Observação: textos dentro dos diagramas continuam editáveis por duplo
   clique no nó ou pelo botão "Editar mapa", pois fazem parte do Mermaid.
*/
var screenEditOn = false;

function cleanScreenText(text){
  return String(text || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+\n/g, '\n')
    .replace(/\n\s+/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .trim();
}
function escapeMarkdownTableCell(text){
  return cleanScreenText(text)
    .replace(/\|/g, '\\|')
    .replace(/\r?\n/g, '<br/>');
}
function elementTextForMarkdown(el){
  if(!el) return '';
  var html = el.innerHTML || '';
  html = html
    .replace(/<br\s*\/?\s*>/gi, '\n')
    .replace(/<\/div>\s*<div>/gi, '\n')
    .replace(/<div>/gi, '')
    .replace(/<\/div>/gi, '')
    .replace(/<\/p>\s*<p>/gi, '\n')
    .replace(/<p>/gi, '')
    .replace(/<\/p>/gi, '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#039;/gi, "'");
  var tmp = document.createElement('div');
  tmp.innerHTML = html;
  return cleanScreenText(tmp.textContent || tmp.innerText || '');
}
function markdownFromTable(table){
  var headers = Array.prototype.slice.call(table.querySelectorAll('thead th')).map(function(th){
    return escapeMarkdownTableCell(elementTextForMarkdown(th));
  });
  if(!headers.length){
    var first = table.querySelector('tr');
    if(first){
      headers = Array.prototype.slice.call(first.children).map(function(cell){
        return escapeMarkdownTableCell(elementTextForMarkdown(cell));
      });
    }
  }
  if(!headers.length) return '';
  var out = [];
  out.push('| ' + headers.join(' | ') + ' |');
  out.push('| ' + headers.map(function(){ return '---'; }).join(' | ') + ' |');
  var rows = Array.prototype.slice.call(table.querySelectorAll('tbody tr'));
  rows.forEach(function(tr){
    var cells = Array.prototype.slice.call(tr.children).map(function(td){
      return escapeMarkdownTableCell(elementTextForMarkdown(td));
    });
    while(cells.length < headers.length) cells.push('');
    if(cells.length > headers.length) cells = cells.slice(0, headers.length);
    out.push('| ' + cells.join(' | ') + ' |');
  });
  return out.join('\n');
}
function markdownFromScreen(){
  var blocks = [];
  var sectionsDom = Array.prototype.slice.call(document.querySelectorAll('#content .doc-section'));
  sectionsDom.forEach(function(sec){
    Array.prototype.slice.call(sec.children).forEach(function(el){
      if(!el || !el.tagName) return;
      var tag = el.tagName.toUpperCase();

      if(/^H[1-4]$/.test(tag)){
        var lvl = parseInt(tag.substring(1), 10);
        var tx = elementTextForMarkdown(el);
        if(tx) blocks.push(Array(lvl + 1).join('#') + ' ' + tx);
        return;
      }
      if(tag === 'P'){
        var p = elementTextForMarkdown(el);
        if(p) blocks.push(p);
        return;
      }
      if(tag === 'UL'){
        var lis = Array.prototype.slice.call(el.querySelectorAll(':scope > li'));
        var listMd = lis.map(function(li){ return '- ' + elementTextForMarkdown(li); }).filter(function(x){ return x.trim() !== '-'; }).join('\n');
        if(listMd) blocks.push(listMd);
        return;
      }
      if(tag === 'OL'){
        var olis = Array.prototype.slice.call(el.querySelectorAll(':scope > li'));
        var olMd = olis.map(function(li, idx){ return (idx + 1) + '. ' + elementTextForMarkdown(li); }).filter(function(x){ return !/^\d+\.\s*$/.test(x); }).join('\n');
        if(olMd) blocks.push(olMd);
        return;
      }
      if(el.classList && el.classList.contains('table-wrapper')){
        var table = el.querySelector('table');
        var mdTable = table ? markdownFromTable(table) : '';
        if(mdTable) blocks.push(mdTable);
        return;
      }
      if(tag === 'TABLE'){
        var mdTable2 = markdownFromTable(el);
        if(mdTable2) blocks.push(mdTable2);
        return;
      }
      if(tag === 'FIGURE' && el.classList.contains('diagram')){
        var target = el.querySelector('.diagram-target');
        var idx = target ? parseInt(target.dataset.idx, 10) : -1;
        if(!isNaN(idx) && diagramCodes[idx]){
          blocks.push('```mermaid\n' + String(diagramCodes[idx]).trim() + '\n```');
        }
        return;
      }
      if(tag === 'PRE'){
        var code = el.textContent || '';
        if(code.trim()) blocks.push('```\n' + code.trim() + '\n```');
        return;
      }
    });
  });
  return blocks.join('\n\n') + '\n';
}
function setScreenEditable(enabled){
  var selectors = '#content h1, #content h2, #content h3, #content h4, #content p, #content li, #content th, #content td';
  document.querySelectorAll(selectors).forEach(function(el){
    // Evita editar texto interno de diagramas SVG/fallbacks.
    if(el.closest('figure.diagram')) return;
    el.contentEditable = enabled ? 'true' : 'false';
    el.spellcheck = false;
    el.classList.toggle('screen-editable', !!enabled);
  });
}
function syncScreenTextToMd(){
  currentMd = markdownFromScreen();
  localStorage.setItem(LS_KEY, currentMd);
  return currentMd;
}
function toggleScreenEdit(){
  var btn = $('btn-screen-edit');
  if(!screenEditOn){
    screenEditOn = true;
    document.body.classList.add('screen-edit-on');
    if(btn){ btn.textContent = 'Concluir edição'; btn.classList.add('on'); }
    setScreenEditable(true);
    showBanner('Edição direta ativada. Clique nos textos, tabelas e títulos para alterar. Para caixas dos diagramas, use duplo clique na caixa.');
    return;
  }

  screenEditOn = false;
  setScreenEditable(false);
  document.body.classList.remove('screen-edit-on');
  if(btn){ btn.textContent = 'Editar tela'; btn.classList.remove('on'); }
  syncScreenTextToMd();
  loadMarkdown(currentMd, true).then(function(){
    showBanner('Edição aplicada. Clique em Salvar .md para baixar a versão atualizada.');
  });
}
function setupScreenTextEdit(){
  var btn = $('btn-screen-edit');
  if(btn) btn.addEventListener('click', toggleScreenEdit);
}

/* ---------- eventos ---------- */
function setupEvents(){
  $('btn-load').addEventListener('click', function(){ showDrop(''); });
  $('btn-save-md').addEventListener('click', saveMd);
  $('btn-present').addEventListener('click', togglePres);
  $('btn-print').addEventListener('click', function(){ if(presOn) exitPres(); window.print(); });
  $('btn-reset').addEventListener('click', function(){ localStorage.removeItem(LS_KEY); location.reload(); });
  $('banner').addEventListener('click', hideBanner);

  $('file-input').addEventListener('change', function(e){ readFile(e.target.files[0]); });
  $('drop-close').addEventListener('click', function(){ $('drop').hidden = true; });

  var drop = $('drop');
  ['dragenter','dragover'].forEach(function(ev){ drop.addEventListener(ev, function(e){ e.preventDefault(); drop.classList.add('drag'); }); });
  ['dragleave','drop'].forEach(function(ev){ drop.addEventListener(ev, function(e){ e.preventDefault(); drop.classList.remove('drag'); }); });
  drop.addEventListener('drop', function(e){ readFile(e.dataTransfer.files[0]); });

  $('pres-prev').addEventListener('click', function(){ showPres(presIdx-1); });
  $('pres-next').addEventListener('click', function(){ showPres(presIdx+1); });
  $('pres-full').addEventListener('click', toggleFull);
  $('pres-exit').addEventListener('click', exitPres);

  document.addEventListener('keydown', function(e){
    if(!$('node-edit-overlay').hidden && e.key==='Escape'){ closeNodeEdit(); return; }
    if(!$('zoom-overlay').hidden && e.key==='Escape'){ closeZoom(); return; }
    if(presOn){
      if(e.key==='ArrowRight' || e.key===' '){ e.preventDefault(); showPres(presIdx+1); }
      else if(e.key==='ArrowLeft'){ e.preventDefault(); showPres(presIdx-1); }
      else if(e.key==='Escape'){ exitPres(); }
      else if(e.key==='f' || e.key==='F'){ toggleFull(); }
    }
  });

  setupZoom();
  setupNodeEdit();
  setupMapEditor();
  setupScreenTextEdit();
}

document.addEventListener('DOMContentLoaded', function(){
  setupEvents();
  boot();
});
