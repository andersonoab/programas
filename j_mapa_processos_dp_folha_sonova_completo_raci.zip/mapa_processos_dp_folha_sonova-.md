# Mapa de Processos DP e Folha — Cluster Sonova (4 CNPJs)

Mapeamento completo dos processos de RH/DP Coordenador Anderson Souza. Paleta Sonova OFC aplicada via classDef em todos os diagramas.

Legenda de cores:

- Azul Sonova #0083CA — ponto de entrada / processo principal
- Azul claro #6EB4DC — agrupador / subdomínio
- Azul escuro #003C64 — decisão / checkpoint
- Vinho #7D0041 — atenção / prazo crítico / encargos
- Verde-petróleo #005A64 — conclusão / arquivamento
- Branco com borda azul — marco de data

## 1. Visão geral

```mermaid
flowchart LR
    HUB(["Gestão de Folha e RH<br/>Cluster Sonova — 6 CNPJs"]):::start

    HUB --> ADM["Admissão"]:::sub
    HUB --> TRF["Transferências entre CNPJs"]:::sub
    HUB --> DES["Desligamento"]:::sub
    HUB --> FOL["Fechamento da Folha"]:::sub
    HUB --> BEN["Benefícios e Lançamentos"]:::sub
    HUB --> PNT["Ponto e Jornada"]:::sub
    HUB --> SST["SST / Segurança"]:::sub
    HUB --> INT["Internalização de Empresas"]:::sub
    HUB --> CAD["Rotinas por Cadência"]:::sub
    HUB --> COM["Comunicados"]:::sub
    HUB --> GST["Onboarding de Gestores<br/>(nova implantação)"]:::sub

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
```

## 2. Admissão

```mermaid
flowchart TD
    T["Talent confirma a Carta Oferta aceita"]:::start
    T --> BV["Eduarda envia boas-vindas"]
    BV --> CK["Checklist digital compartilhado<br/>Talent + DP (dispara no aceite)"]:::deci
    CK --> DOC["Coleta de documentação<br/>(link para o colaborador subir docs)"]
    DOC --> EX["Exame médico admissional"]
    DOC --> VT["Vale Transporte"]
    DOC --> VR["Vale Refeição"]
    EX --> REV["Eduarda revisa e aprova"]
    VT --> REV
    VR --> REV
    REV --> DP["Inclusão na DP / sistema"]

    DP --> QZ["Registro de opção pelo quinzenal<br/>(documentado no cadastro)"]
    DP --> CTPS["CTPS digital + consignados<br/>(na admissão inicial)"]
    DP --> SUL["Atualizar SulAmérica e VT"]
    DP --> INTEG["Treinamento de integração obrigatório<br/>com certificação (Anvisa / RDC 665)"]:::aten
    INTEG --> CONF["Conferência mensal dos<br/>certificados de integração"]
    DP --> PNT["Incluir no sistema de ponto<br/>(laboratório) + confirmar no 1º dia útil"]
    DP --> COMA["Comunicado de admissão<br/>(jornada, ponto, benefícios)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 3. Transferências entre CNPJs

```mermaid
flowchart TD
    SOL["Solicitação formal de transferência<br/>(formulário digital padrão)"]:::start
    SOL --> GR["Gerente regional registra a mudança"]
    GR --> VIS["RH com visibilidade<br/>antes do processamento da folha"]:::deci
    VIS --> CONF["Amarrar na etapa de conferência da folha"]
    CONF --> OK["Cada CNPJ com as pessoas corretas<br/>(ciclo fechado, sem quebra de comunicação)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 4. Desligamento

```mermaid
flowchart TD
    GAT["Gatilho de desligamento"]:::start
    GAT --> CKD["Checklist de Desligamento<br/>(antes da rescisão)"]:::deci
    CKD --> M1["Devolução de materiais"]
    CKD --> M2["Consentimento de exclusão de arquivos"]
    CKD --> M3["Termo correto<br/>(aviso prévio, justa causa, etc.)"]
    M1 --> RES["DP processa a rescisão"]
    M2 --> RES
    M3 --> RES

    GAT --> CD["Comissões de desligados<br/>prazo D+2 após o desligamento"]:::aten
    CD --> FCP["Input prioritário na folha complementar"]
    GAT --> IFO["Ajustar iFood na demissão"]

    RES --> COMD["Comunicado de desligamento<br/>(prazos e direitos)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 5. Fechamento da Folha (ciclo completo)

```mermaid
flowchart TD
    A["1. Calcular folha com<br/>todas as rubricas já lançadas"]:::start
    A --> B["2. Conferência com sistema de outliers"]:::deci
    B --> C["3. Incluir comissões fora do fluxo<br/>(Lilian / regionais)"]
    C --> D["4. Consolidar e verificar o líquido final"]
    D --> E["5. Separar folhas por áreas"]
    E --> F["6. Calcular FTEs (full-time equivalents) para as HRMs"]
    F --> G["7. Gerar arquivos bancários"]
    G --> H["8. Subir no BankManager"]
    H --> I["9. Aprovações no Pipefy e no SSA"]
    I --> J["Pré-conferência de encargos<br/>INSS / FGTS / eSocial (antes da semana 1)"]:::aten
    J --> K["10. Conferência final de encargos<br/>INSS / FGTS antes de enviar ao banco"]:::aten
    K --> L["11. Fechar e arquivar<br/>comprovantes + folha final (auditoria)"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 6. Calendário de lançamentos (inputs da folha)

```mermaid
flowchart LR
    D1(["Dia 1"]):::date
    D1 --> U1["Upload de bases:<br/>Sonova Cuida, Unives, Wellhub, Petlove"]
    D1 --> U2["Consignado + Copay"]
    D1 --> U3["Seguro de vida<br/>(incluir admitidos / retirar desligados)"]

    D2(["Dia 2"]):::date --> G["Gympass"]
    DX(["<p></p><p>Dia 20</p><p></p>"]):::date --> CR["Creche e Educação"]
    IFC(["Ao comprar"]):::date --> IF["iFood gera automaticamente"]
    D20(["Dia 20"]):::date --> CM["Recebimento de comissões"]
    D21(["Dia 21"]):::date --> VC["Validação de comissões"]

    classDef date fill:#fff,stroke:#0083CA,stroke-width:2px,color:#0083CA;
```

## 7. Férias (duas janelas fixas)

```mermaid
flowchart TD
    J1(["Janela 1 — até o dia 20"]):::date
    J1 --> F1["Calcular férias que iniciam<br/>no começo do próximo mês"]
    F1 --> FF["Entram no 1º cálculo, junto com a folha<br/>(garante pagamento no mês corrente)"]:::done

    J2(["Janela 2 — 1ª semana do mês seguinte"]):::date
    J2 --> F2["Calcular férias que iniciam mais adiante"]

    classDef date fill:#fff,stroke:#0083CA,stroke-width:2px,color:#0083CA;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 8. Benefícios — VT / VR / VA

```mermaid
flowchart TD
    FC["Folha fechada<br/>(antes do dia 15)"]:::start
    FC --> CS["Conferência de saldo"]:::deci
    CS --> XR["Cruzar bases VT x VR<br/>checar saldo de todos os CNPJs"]
    XR --> CP["Compra consolidada (única)"]
    CP --> RB["VT via RB Ticket"]
    CP --> IFV["VR / VA via iFood"]
    RB --> OK["Benefícios comprados no prazo, sem erro"]:::done
    IFV --> OK

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 9. Quinzenal

```mermaid
flowchart TD
    AD["Admissão"]:::start --> OP["Registro de opção pelo quinzenal<br/>(no cadastro)"]
    OP --> FT["Filtro: somente quem optou"]:::deci
    FT --> P15["Dia 15 — pagamento apenas aos optantes"]:::done

    NQ["Empresas sem quinzenal"]:::start --> FN["Seguem o fluxo normal"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 10. Ponto e jornada

```mermaid
flowchart LR
    P["Gestão de Ponto e Jornada"]:::start

    P --> BA["Quem bate ponto"]:::sub
    BA --> R1["Relógio funcionando + horários configurados"]
    BA --> R2["Ciclo de fechamento antes do fim do mês"]
    R2 --> R3["Conferir horas extras e faltas"]

    P --> NB["Quem não bate ponto"]:::sub
    NB --> N1["Controle de jornada alternativo"]
    NB --> N2["Acordo individual de horário flexível"]
    N2 --> N3["Revisões periódicas da jornada"]

    P --> LAB["Laboratório (na admissão)"]:::sub
    LAB --> L1["Incluir no sistema de ponto na entrada"]
    L1 --> L2["Confirmar habilitação no 1º dia útil"]
    L2 --> L3["Orientar o colaborador a registrar as marcações"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
```

## 11. SST / Segurança

```mermaid
flowchart LR
    SST["SST / Segurança"]:::start

    SST --> V["Vencimentos e laudos"]:::sub
    V --> V1["Validade de PGR<br/>(relatório com a Essência + alertas)"]
    V --> V2["EPI / PGR"]
    V --> V3["Atualização de laudos (LTCAT)"]

    SST --> TR["Treinamentos"]:::sub
    TR --> T1["NR-5 (CIPA)"]
    TR --> T2["NR-6 (EPI)"]
    TR --> T3["Reciclagem periódica"]

    SST --> EM["Emergência e rotina"]:::sub
    EM --> E1["Revisão anual do plano de emergência"]
    EM --> E2["DDS — Diálogo Diário de Segurança"]
    EM --> E3["Auditorias internas de rotina"]
    EM --> E4["Comunicação formal de incidentes"]:::aten
    EM --> E5["Revisão dos procedimentos de emergência"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 12. Internalização de empresas (meta: até 60 dias)

```mermaid
flowchart LR
    I["Internalização de Empresa<br/>(meta: até 60 dias)"]:::start

    I --> C1["Revisar contratos de trabalho → aditivos"]
    C1 --> C2["Transferência de responsabilidades no contrato"]

    I --> M1["Migração de dados de folha e benefícios"]
    M1 --> M2["Portabilidade de plano de saúde / odonto"]
    M2 --> M3["Adequação de benefícios (VR, VA, previdência)"]
    M3 --> M4["Migração de férias e banco de horas"]

    I --> S1["EPIs e treinamentos de segurança alinhados"]
    I --> S2["Atualizar cadastro (novos gestores e cargos)"]
    S2 --> S3["Integração no eSocial"]

    I --> P1["Formalização de políticas internas"]
    P1 --> P2["Atualizar acessos a sistemas internos"]
    P2 --> P3["Revisitar política de LGPD"]:::aten

    I --> CC["Comunicação clara aos colaboradores<br/>sobre o novo vínculo"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 13. Rotinas por cadência

```mermaid
flowchart LR
    CAD["Rotinas por Cadência"]:::start

    CAD --> DI["Diárias"]:::sub
    DI --> DI1["RH Informs (chamados) — janela fixa,<br/>macro no Google Sheets organiza as respostas"]
    DI --> DI2["Atestados — registrar no eSocial<br/>em até 1 dia útil"]:::aten
    DI --> DI3["Centralizar atestados via RH Informs / formulário"]
    DI --> DI4["Controle de acesso à DP"]

    CAD --> SE["Semanais"]:::sub
    SE --> SE1["Controle Solan (sexta-feira) —<br/>revisar notas e aprovar lançamentos"]

    CAD --> ME["Mensais"]:::sub
    ME --> ME1["FAP — consultar alíquota e ajustar por CNPJ<br/>antes do fechamento"]
    ME --> ME2["Validade de PGRs"]
    ME --> ME3["Atualização das bases de benefícios"]

    CAD --> SM["Semestrais"]:::sub
    SM --> SM1["Igualdade salarial"]

    CAD --> AN["Anuais"]:::sub
    AN --> AN1["Budget (último trimestre)"]
    AN --> AN2["DIRF / RAIS (início do ano)"]
    AN --> AN3["BSC (início do ano)"]
    AN --> AN4["Vacinação (2º semestre)"]
    AN --> AN5["Cartas de promoção e mérito (abril e outubro)"]
    AN --> AN6["PLR — comissão no início, checkpoints<br/>trimestrais, pagamento no fim do ano"]
    AN --> AN7["Revisão de CCT / convenções coletivas"]
    AN --> AN8["Auditoria interna de DP / RH"]
    AN --> AN9["Revisão de política de benefícios e clima"]
    AN --> AN10["Impacto do salário mínimo e faixas de IR"]
    AN --> AN11["Cotas de aprendizes e PCD"]
    AN --> AN12["Reavaliação de cargos e salários + plano de sucessão"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef sub fill:#6EB4DC,stroke:#003C64,stroke-width:1px,color:#003C64;
    classDef aten fill:#7D0041,stroke:#003C64,stroke-width:1px,color:#fff;
```

## 14. Comunicados-chave

```mermaid
flowchart LR
    C["Comunicados-chave"]:::start
    C --> C1["Admissão<br/>(jornada, ponto, benefícios)"]
    C --> C2["Desligamento<br/>(prazos e direitos)"]
    C --> C3["Atualização anual<br/>(PLR, reajustes, CCT)"]
    C --> C4["Geral<br/>(prazos de atestados, férias, ponto)"]

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
```

## 15. Onboarding de gestores (nova implantação / mudança de regra)

```mermaid
flowchart TD
    NI["Nova implantação ou mudança de regra"]:::start
    NI --> MF["Microfluxo de adaptação (antes)"]:::deci
    MF --> MO["Mini onboarding dos gestores<br/>(nova cultura, regras, pontos de atenção)"]
    MO --> FN["Inserir no fluxo padrão"]:::done

    classDef start fill:#0083CA,stroke:#003C64,stroke-width:2px,color:#fff;
    classDef deci fill:#003C64,stroke:#003C64,stroke-width:1px,color:#fff;
    classDef done fill:#005A64,stroke:#003C64,stroke-width:1px,color:#fff;
```
