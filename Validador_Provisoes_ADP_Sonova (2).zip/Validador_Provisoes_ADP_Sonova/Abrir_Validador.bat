@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_RUN=py"
) else (
    set "PYTHON_RUN=python"
)
%PYTHON_RUN% -c "import pdfplumber" >nul 2>nul
if errorlevel 1 (
    echo Instalando a dependencia de leitura de PDF...
    %PYTHON_RUN% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo Falha na instalacao. Instale Python 3.10 ou superior e execute novamente.
        pause
        exit /b 1
    )
)
%PYTHON_RUN% Validador_Provisoes_ADP.py
if errorlevel 1 pause
