#!/usr/bin/env python3
"""Validador local de provisões ADP: férias e 13º salário detalhados."""
from __future__ import annotations

import csv
import html
import json
import re
import statistics
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

try:
    import pdfplumber
except ImportError:
    print("Instale a dependência: py -m pip install pdfplumber", file=sys.stderr)
    raise

MONEY = r"(?:\d{1,3}(?:\.\d{3})*|\d+),\d{2}-?"
AMOUNTS = re.compile(MONEY)
EMP = re.compile(r"^\s*(\d{1,8})\s+(.+?)\s+(Ativo|Afastado|Demitido)\s+(" + MONEY + r")\s+(.+)$", re.I)
MONTHS = {"janeiro": 1, "fevereiro": 2, "março": 3, "marco": 3, "abril": 4, "maio": 5,
          "junho": 6, "julho": 7, "agosto": 8, "setembro": 9, "outubro": 10, "novembro": 11, "dezembro": 12}
FIELDS = ("anterior", "mes", "ajuste", "baixa", "atual")


def cents(s):
    s = s.strip()
    sign = -1 if s.endswith("-") or s.startswith("-") else 1
    return sign * int(s.strip("-").replace(".", "").replace(",", ""))


def br(n):
    return f"{n / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


@dataclass
class Entry:
    arquivo: str
    tipo: str
    competencia: str
    cnpj: str
    matricula: str
    nome: str
    situacao: str
    salario: int
    quantidade: float
    pagina: int
    verbas: dict = field(default_factory=dict)
    antecipacao: int = 0


def parse_pdf(path):
    path = Path(path)
    entries, totals, notes = [], {}, []
    with pdfplumber.open(path) as pdf:
        text0 = pdf.pages[0].extract_text() or ""
        kind = "13º" if "13º Salário Detalhado" in text0 else ("Férias" if "Férias Detalhado" in text0 else None)
        if not kind:
            raise ValueError(f"{path.name}: formato não reconhecido (esperado ADP Provisão de 13º ou Férias Detalhado)")
        cnpj = re.search(r"\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}", text0)
        period = re.search(r"Referente:\s*([A-Za-zÀ-ÿ]+)\s*/\s*(\d{4})", text0, re.I)
        if not cnpj or not period or period.group(1).lower() not in MONTHS:
            raise ValueError(f"{path.name}: CNPJ ou competência ausente")
        competence = f"{period.group(2)}-{MONTHS[period.group(1).lower()]:02d}"
        active = None
        for page_no, page in enumerate(pdf.pages, 1):
            body = page.extract_text(layout=True, x_density=5.5, y_density=13) or ""
            for line in body.splitlines():
                tm = re.search(r"Total Seleção:.*?\b(13ºSal\.|Férias)\s+(.+)", line)
                if tm:
                    nums = AMOUNTS.findall(tm.group(2))
                    if len(nums) == 5:
                        totals["Principal"] = dict(zip(FIELDS, map(cents, nums)))
                    active = None
                    continue
                m = EMP.match(line)
                if m:
                    matricula, nome, situacao, sal, rest = m.groups()
                    label = "13ºSal." if kind == "13º" else "Férias"
                    if label not in rest:
                        continue
                    left, right = rest.split(label, 1)
                    nums = AMOUNTS.findall(right)
                    x = AMOUNTS.findall(left)
                    avos = re.match(r"^\s*(" + MONEY + r")\s+(\d+)\s*$", left) if kind == "13º" else None
                    if len(nums) != 5 or (kind == "13º" and not avos) or (kind == "Férias" and len(x) != 1):
                        notes.append(f"{path.name}, página {page_no}: linha não interpretada: {line.strip()[:120]}")
                        active = None
                        continue
                    active = Entry(path.name, kind, competence, cnpj.group(), matricula, nome.strip(),
                                   situacao.capitalize(), cents(sal), float(avos.group(2) if avos else x[-1].replace(",", ".")), page_no,
                                   {"Principal": dict(zip(FIELDS, map(cents, nums)))},
                                   cents(x[0]) if kind == "13º" else 0)
                    entries.append(active)
                    continue
                em = re.search(r"\b(INSS|FGTS)\s+(" + MONEY + r")\s+(" + MONEY + r")\s+(" + MONEY + r")\s+(" + MONEY + r")\s+(" + MONEY + r")", line)
                if em:
                    category = em.group(1)
                    row = dict(zip(FIELDS, [cents(x) for x in em.groups()[1:]]))
                    if "Total Seleção" in line or active is None:
                        totals[category] = row
                    else:
                        active.verbas[category] = row
            # Totais de INSS e FGTS aparecem após a linha Total Seleção, inclusive em outra página.
        if not entries or not totals.get("Principal"):
            raise ValueError(f"{path.name}: sem pessoas ou sem total de seleção")
        for e in entries:
            if set(e.verbas) != {"Principal", "INSS", "FGTS"}:
                notes.append(f"{e.matricula} {e.nome}: faltam linhas de encargos")
        for label in ("INSS", "FGTS"):
            if label not in totals:
                notes.append(f"{path.name}: total de {label} não localizado")
    return entries, totals, notes


def analyze(paths):
    files, all_entries, alerts, reconciliation = [], [], [], []
    for path in paths:
        entries, totals, notes = parse_pdf(path)
        files.append({"arquivo": Path(path).name, "tipo": entries[0].tipo, "competencia": entries[0].competencia,
                      "cnpj": entries[0].cnpj, "pessoas": len(entries), "observacoes": notes})
        all_entries.extend(entries)
        for label in ("Principal", "INSS", "FGTS"):
            for field_name in FIELDS:
                calculated = sum(e.verbas.get(label, {}).get(field_name, 0) for e in entries)
                printed = totals.get(label, {}).get(field_name)
                reconciliation.append({"arquivo": Path(path).name, "verba": label, "campo": field_name,
                                       "calculado": calculated, "impresso": printed,
                                       "diferenca": None if printed is None else calculated - printed})
                if printed is None or abs(calculated - printed) > 1:
                    alerts.append(make_alert(entries[0], label, "Reconciliação", "Crítico",
                               f"{field_name}: soma {br(calculated)}, impresso {br(printed) if printed is not None else 'ausente'}",
                               calculated - (printed or 0), None))
        for note in notes:
            alerts.append(make_alert(entries[0], "Arquivo", "Extração", "Crítico", note, 0, None))

    reference_rates = {}
    for file_info in files:
        file_rows = [e for e in all_entries if e.arquivo == file_info["arquivo"]]
        for verba in ("FGTS", "INSS"):
            ratios = [e.verbas[verba]["atual"] / e.verbas["Principal"]["atual"] for e in file_rows
                      if e.verbas["Principal"]["atual"] > 0 and verba in e.verbas]
            if len(ratios) >= 5:
                reference_rates[(file_info["arquivo"], verba)] = statistics.median(ratios)
    groups = defaultdict(list)
    for e in all_entries:
        groups[(e.cnpj, e.competencia, e.tipo, e.matricula)].append(e)
        p = e.verbas["Principal"]
        flow = p["mes"] + p["ajuste"] + p["baixa"]
        if e.tipo == "Férias" and e.quantidade > 90:
            alerts.append(make_alert(e, "Principal", "Saldo de dias", "Alto",
                          f"{e.quantidade:g} dias de férias provisionados; conferir períodos aquisitivos, gozo e perdas.", p["atual"], None))
        elif e.tipo == "Férias" and e.quantidade > 60:
            alerts.append(make_alert(e, "Principal", "Saldo de dias", "Atenção",
                          f"{e.quantidade:g} dias de férias provisionados; verificar antiguidade do saldo.", p["atual"], None))
        if e.tipo == "13º" and not 0 <= e.quantidade <= 12:
            alerts.append(make_alert(e, "Principal", "Avos", "Alto", f"{e.quantidade:g} avos fora de 0 a 12.", p["atual"], None))
        if e.situacao == "Demitido" and p["atual"] != 0:
            alerts.append(make_alert(e, "Principal", "Demitido com saldo", "Alto", "Saldo remanescente após desligamento.", p["atual"], None))
        if e.situacao == "Afastado" and p["atual"] > 0:
            alerts.append(make_alert(e, "Principal", "Afastamento", "Revisar",
                          "Saldo mantido durante afastamento; conferir natureza e datas do afastamento.", p["atual"], None))
        if e.situacao != "Demitido" and (abs(p["ajuste"]) >= 100000 or (abs(p["ajuste"]) >= 50000 and abs(p["ajuste"]) > abs(p["mes"]))):
            alerts.append(make_alert(e, "Principal", "Ajuste material", "Alto" if abs(p["ajuste"]) >= 100000 else "Atenção",
                          f"Ajuste {br(p['ajuste'])}, mensal {br(p['mes'])}; validar alteração salarial, média e retroatividade.", p["ajuste"], None))
        if p["mes"] > 0 and p["ajuste"] <= -p["mes"]:
            alerts.append(make_alert(e, "Principal", "Estorno mensal", "Atenção",
                          f"Ajuste {br(p['ajuste'])} anulou a provisão do mês {br(p['mes'])}.", flow, None))
        if e.tipo == "13º" and e.antecipacao > 0:
            alerts.append(make_alert(e, "Principal", "Antecipação", "Informativo",
                          f"Antecipação registrada: {br(e.antecipacao)}. Conferir tratamento no pagamento final; não somar à provisão.", e.antecipacao, None))
        if e.tipo == "13º" and e.situacao == "Ativo" and e.quantidade > 0:
            nominal = round(e.salario * e.quantidade / 12)
            if abs(p["atual"] - nominal) > max(50000, int(nominal * .25)):
                alerts.append(make_alert(e, "Principal", "Base de 13º", "Revisar",
                              f"Acumulado {br(p['atual'])} difere de salário × avos/12 ({br(nominal)}); médias podem explicar.",
                              p["atual"] - nominal, None))
        for verba in ("FGTS", "INSS"):
            if verba not in e.verbas:
                continue
            rate = reference_rates.get((e.arquivo, verba))
            if rate is None:
                continue
            v = e.verbas[verba]
            for field_name in ("atual",):
                expected = int((Decimal(p[field_name]) * Decimal(str(rate))).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                # INSS patronal pode variar em outras empresas; discrepância é apenas para revisão.
                tolerance = max(3, abs(p[field_name]) // 1000)
                if abs(v[field_name] - expected) > tolerance and abs(p[field_name]) >= 10000:
                    apparent = 100 * v[field_name] / p[field_name] if p[field_name] else 0
                    alerts.append(make_alert(e, verba, "Alíquota aparente", "Revisar",
                                  f"Acumulado: {br(v[field_name])} ({apparent:.2f}%) vs {br(expected)} pela mediana deste PDF ({rate * 100:.2f}%). Conferir parametrização.",
                                  v[field_name] - expected, None))
        for label, v in e.verbas.items():
            diff = v["anterior"] + v["mes"] + v["ajuste"] + v["baixa"] - v["atual"]
            if abs(diff) > 1:
                alerts.append(make_alert(e, label, "Equação do saldo", "Crítico",
                              f"Anterior + mês + ajuste + baixa - atual = {br(diff)}.", diff, None))
    for group in groups.values():
        if len(group) > 1:
            e = group[0]
            alerts.append(make_alert(e, "Principal", "Duplicidade", "Crítico", f"Matrícula repetida {len(group)} vezes no mesmo tipo/CNPJ/competência.", 0, None))
    cross = defaultdict(dict)
    for e in all_entries:
        cross[(e.cnpj, e.competencia, e.matricula)][e.tipo] = e
    for pair in cross.values():
        if len(pair) == 2:
            a, b = pair["13º"], pair["Férias"]
            if a.salario != b.salario:
                alerts.append(make_alert(a, "Principal", "Salário cruzado", "Alto",
                              f"13º {br(a.salario)} vs férias {br(b.salario)}.", a.salario - b.salario, None))
            if a.situacao != b.situacao:
                alerts.append(make_alert(a, "Principal", "Situação cruzada", "Alto",
                              f"13º {a.situacao} vs férias {b.situacao}.", 0, None))
    return {"arquivos": files, "registros": all_entries, "alertas": alerts, "reconciliacao": reconciliation}


def make_alert(e, verba, regra, severidade, motivo, valor, _):
    return {"arquivo": e.arquivo, "tipo": e.tipo, "competencia": e.competencia, "cnpj": e.cnpj,
            "matricula": e.matricula, "nome": e.nome, "situacao": e.situacao, "verba": verba,
            "regra": regra, "severidade": severidade, "motivo": motivo, "valor": valor, "pagina": e.pagina}


def export_csv(data, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0]) if data else ["sem_dados"], delimiter=";")
        writer.writeheader()
        for item in data:
            writer.writerow({k: br(v) if k == "valor" and isinstance(v, int) else v for k, v in item.items()})


def export_html(result, path):
    esc = lambda x: html.escape(str(x))
    rows = []
    for a in result["alertas"]:
        rows.append("<tr>" + "".join(f"<td>{esc(br(a[k]) if k == 'valor' else a[k])}</td>" for k in
                    ("tipo", "competencia", "matricula", "nome", "verba", "regra", "severidade", "valor", "motivo", "pagina")) + "</tr>")
    rec = []
    for x in result["reconciliacao"]:
        rec.append("<tr>" + "".join(f"<td>{esc(br(x[k]) if isinstance(x[k], int) else ('ausente' if x[k] is None else x[k]))}</td>" for k in
                   ("arquivo", "verba", "campo", "calculado", "impresso", "diferenca")) + "</tr>")
    document = """<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Auditoria de provisões</title>
<style>body{font:14px Arial,sans-serif;margin:32px;color:#173448}h1,h2{color:#0083ca}table{border-collapse:collapse;width:100%;font-size:12px}th,td{padding:8px;border-bottom:1px solid #ddd;text-align:left}th{border-bottom:2px solid #0083ca}tr:hover{outline:1px solid #0083ca}.note{color:#555}input{padding:9px;width:300px}@media print{input{display:none}body{margin:12mm}}</style>
<h1>Auditoria de provisões ADP</h1><p class="note">Alertas são pontos de revisão, não erros confirmados. A coluna valor não deve ser somada entre regras.</p>
<h2>Reconciliação</h2><table><thead><tr><th>Arquivo</th><th>Verba</th><th>Campo</th><th>Soma</th><th>PDF</th><th>Diferença</th></tr></thead><tbody>""" + "".join(rec) + """</tbody></table>
<h2>Alertas</h2><input id="busca" placeholder="Buscar nome, matrícula, regra..." oninput="filtrar()"><table id="alertas"><thead><tr><th>Tipo</th><th>Competência</th><th>Matrícula</th><th>Nome</th><th>Verba</th><th>Regra</th><th>Severidade</th><th>Valor</th><th>Motivo</th><th>Página</th></tr></thead><tbody>""" + "".join(rows) + """</tbody></table>
<script>function filtrar(){let q=document.getElementById('busca').value.toLocaleLowerCase();document.querySelectorAll('#alertas tbody tr').forEach(r=>r.hidden=!r.textContent.toLocaleLowerCase().includes(q))}</script></html>"""
    Path(path).write_text(document, encoding="utf-8")


def gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    root = tk.Tk()
    root.title("Validador de Provisões ADP | Sonova")
    root.geometry("1380x780")
    result = {"alertas": [], "registros": [], "reconciliacao": [], "arquivos": []}
    selected_months = set()
    columns = ("tipo", "competencia", "matricula", "nome", "verba", "regra", "severidade", "valor", "motivo", "pagina")
    sort = {"key": "", "reverse": False}
    bar = ttk.Frame(root, padding=10)
    bar.pack(fill="x")
    summary = tk.StringVar(value="Selecione PDFs de provisão de férias e/ou 13º salário.")
    ttk.Label(root, textvariable=summary, padding=(12, 2)).pack(anchor="w")
    filters = ttk.Frame(root, padding=10)
    filters.pack(fill="x")
    ttk.Label(filters, text="Competências (Ctrl+clique):").pack(side="left")
    months = tk.Listbox(filters, selectmode="multiple", height=3, width=13, exportselection=False)
    months.pack(side="left", padx=8)
    term = tk.StringVar()
    ttk.Label(filters, text="Busca:").pack(side="left")
    ttk.Entry(filters, textvariable=term, width=25).pack(side="left", padx=8)
    severity = tk.StringVar(value="Todas")
    ttk.Combobox(filters, values=("Todas", "Crítico", "Alto", "Atenção", "Revisar", "Informativo"),
                 textvariable=severity, state="readonly", width=14).pack(side="left", padx=8)
    kind = tk.StringVar(value="Todos")
    ttk.Combobox(filters, values=("Todos", "Férias", "13º"), textvariable=kind, state="readonly", width=10).pack(side="left")
    include_terminated = tk.BooleanVar(value=True)
    ttk.Checkbutton(filters, text="Incluir demitidos", variable=include_terminated).pack(side="left", padx=10)
    show_alerts = tk.BooleanVar(value=True)
    ttk.Checkbutton(filters, text="Somente alertas", variable=show_alerts).pack(side="left", padx=8)
    tree = ttk.Treeview(root, columns=columns, show="headings", selectmode="browse")
    widths = (65, 85, 75, 220, 70, 140, 95, 100, 440, 45)
    for key, width in zip(columns, widths):
        tree.heading(key, text=key.title())
        tree.column(key, width=width, minwidth=50, stretch=key in ("nome", "motivo"))
    tree.pack(fill="both", expand=True, padx=10, pady=8)
    visible = []
    def filtered():
        months_selected = {months.get(i) for i in months.curselection()}
        if not months_selected:
            return []
        q = term.get().casefold().strip()
        source = result["alertas"] if show_alerts.get() else [make_alert(e, "Principal", "Registro", "Base",
                 f"Anterior {br(e.verbas['Principal']['anterior'])}; mês {br(e.verbas['Principal']['mes'])}; ajuste {br(e.verbas['Principal']['ajuste'])}; baixa {br(e.verbas['Principal']['baixa'])}.",
                 e.verbas['Principal']['atual'], None) for e in result["registros"]]
        return [a for a in source if a["competencia"] in months_selected
                and (severity.get() == "Todas" or a["severidade"] == severity.get())
                and (kind.get() == "Todos" or a["tipo"] == kind.get())
                and (include_terminated.get() or a["situacao"] != "Demitido")
                and (not q or q in " ".join(str(v) for v in a.values()).casefold())]
    def refresh(*_):
        visible[:] = filtered()
        if sort["key"]:
            visible.sort(key=lambda a: (a[sort["key"]] is None, a[sort["key"]]), reverse=sort["reverse"])
        tree.delete(*tree.get_children())
        for i, a in enumerate(visible):
            tree.insert("", "end", iid=str(i), values=[br(a[k]) if k == "valor" else a[k] for k in columns])
        bad = sum(1 for x in result["reconciliacao"] if x["diferenca"] is None or abs(x["diferenca"]) > 1)
        summary.set(f"{len(result['arquivos'])} arquivo(s) | {len(result['registros'])} registros | {len(visible)} alertas visíveis | {bad} divergência(s) de reconciliação. Duplo clique abre a ficha.")
    def load():
        paths = filedialog.askopenfilenames(title="Selecione os PDFs", filetypes=[("PDF", "*.pdf")])
        if not paths: return
        try:
            new = analyze(paths)
        except Exception as ex:
            messagebox.showerror("Falha na leitura", str(ex)); return
        result.update(new)
        months.delete(0, "end")
        for m in sorted({x["competencia"] for x in result["arquivos"]}): months.insert("end", m)
        months.selection_set(0, "end")
        refresh()
    def detail(_):
        sel = tree.selection()
        if not sel: return
        alert = visible[int(sel[0])]
        match = next((e for e in result["registros"] if e.arquivo == alert["arquivo"] and e.matricula == alert["matricula"]), None)
        win = tk.Toplevel(root); win.title(f"Ficha - {alert['matricula']} {alert['nome']}"); win.geometry("820x560")
        txt = tk.Text(win, wrap="word", font=("Consolas", 11), padx=16, pady=16)
        txt.pack(fill="both", expand=True)
        txt.insert("end", f"{alert['nome']} | Matrícula {alert['matricula']} | {alert['situacao']}\n{alert['arquivo']} - página {alert['pagina']}\n")
        if match:
            txt.insert("end", f"CNPJ {match.cnpj} | {match.competencia} | salário {br(match.salario)} | {'avos' if match.tipo == '13º' else 'dias'} {match.quantidade:g}\n")
            if match.antecipacao: txt.insert("end", f"Antecipação: {br(match.antecipacao)}\n")
            txt.insert("end", "\nVerba            Anterior        Mês      Ajuste       Baixa       Atual\n")
            for label, amounts in match.verbas.items():
                txt.insert("end", f"{label:<10}" + "".join(f"{br(amounts[k]):>12}" for k in FIELDS) + "\n")
        txt.insert("end", "\nAlertas relacionados:\n")
        for a in result["alertas"]:
            if a["arquivo"] == alert["arquivo"] and a["matricula"] == alert["matricula"]:
                txt.insert("end", f"• {a['severidade']} | {a['regra']}: {a['motivo']}\n")
        txt.configure(state="disabled")
    def ordering(col):
        sort.update(key=col, reverse=not sort["reverse"] if sort["key"] == col else False)
        refresh()
        for c in columns: tree.heading(c, text=c.title() + (" ▼" if sort["reverse"] else " ▲") if c == col else c.title())
    for col in columns: tree.heading(col, command=lambda c=col: ordering(c))
    def save(mode):
        if mode == "CSV":
            path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
            if path: export_csv(visible, path)
        elif mode == "HTML":
            path = filedialog.asksaveasfilename(defaultextension=".html", filetypes=[("HTML", "*.html")])
            if path:
                chosen_files = {a["arquivo"] for a in result["arquivos"] if a["competencia"] in {months.get(i) for i in months.curselection()}}
                subset = {**result, "alertas": list(visible), "reconciliacao": [r for r in result["reconciliacao"]
                    if r["arquivo"] in chosen_files]}
                export_html(subset, path)
    ttk.Button(bar, text="Abrir PDFs", command=load).pack(side="left", padx=4)
    ttk.Button(bar, text="Exportar alertas filtrados (CSV)", command=lambda: save("CSV")).pack(side="left", padx=4)
    ttk.Button(bar, text="Relatório filtrado (HTML)", command=lambda: save("HTML")).pack(side="left", padx=4)
    ttk.Button(bar, text="Imprimir relatório", command=lambda: messagebox.showinfo("Impressão", "Exporte o HTML filtrado e use Ctrl+P no navegador.")).pack(side="left", padx=4)
    term.trace_add("write", refresh)
    severity.trace_add("write", refresh)
    kind.trace_add("write", refresh)
    include_terminated.trace_add("write", refresh)
    show_alerts.trace_add("write", refresh)
    months.bind("<<ListboxSelect>>", refresh)
    tree.bind("<Double-1>", detail)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        data = analyze(sys.argv[1:])
        print(json.dumps({"arquivos": data["arquivos"], "alertas": data["alertas"],
                          "reconciliacao": data["reconciliacao"]}, ensure_ascii=False, indent=2))
    else:
        gui()
